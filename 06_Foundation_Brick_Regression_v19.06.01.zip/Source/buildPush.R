#########################################################################
# Build Push script
# Vivekananda 
# Version 1.01
# Script for runnign test cases and uploading metrics during a build push
# Revisions version 01, Anubhav Agrawal 
# * Added script for uploading metrics
#########################################################################

start = Sys.time()
library(testthat)
library(compare)
library(futile.logger)
set.seed(7)


flog.threshold(INFO)
# flog.appender(appender.file("./testCaseSummary.log"))
flog.appender(appender.file("./testCases.log"))
testResults <- as.data.frame(test_file("testCases.R"))
print(testResults)
summary <- list()
summary[['Number of tests run']] <- nrow(testResults)#196
summary[['Numeber of tests failed']] <- sum(testResults$failed)


# ########################### UI TEST CASES ###################################
# library(png)
# library(shinytest)
# compare.images <- function(img1, img2){
#   img1 <- readPNG(paste0("../tests/mytest-current/", img1))
#   img2 <- readPNG(paste0("../tests/mytest-expected/", img2))
#   img1 <- img1[150:nrow(img1),1:ncol(img1),]
#   img2 <- img2[150:nrow(img2),1:ncol(img2),]
#   return(identical(img1, img2))
# }
# compare.images1 <- function(img1, img2){
#   img1 <- readPNG(paste0("../tests/mytest-current/", img1))
#   img2 <- readPNG(paste0("../tests/mytest-expected/", img2))
#   img1 <- img1[150:29000,1:ncol(img1),]
#   img2 <- img2[150:29000,1:ncol(img2),]
#   return(identical(img1, img2))
# }
# results <- testApp("../Foundation_Brick_Regression.rmd", testnames = "mytest", quiet = T, interactive = F)
# if(dir.exists("../tests/mytest-current/")){
#   currentImages <- list.files(path = "../tests/mytest-current/", pattern = "*.png")
#   expectedImages <- list.files(path = "../tests/mytest-expected/", pattern = "*.png")
#   result <- mapply(compare.images, currentImages[0:38], expectedImages[0:38])
#   img1 <- readPNG("../tests/mytest-current/039.png")
#   img2 <- readPNG("../tests/mytest-expected/039.png")
#   result1 <- identical(img1[450:29000, 1:ncol(img1), ], img2[450:29000, 1:ncol(img2), ])
#   rm(img1, img2)
#   result2 <- mapply(compare.images1, currentImages[c(39:41, 43:44)], expectedImages[c(39:41, 43:44)])
#   if(all(result) == TRUE && all(result2) == TRUE && result1 == TRUE){
#     compareImages <- "test cases passed"
#   } else{
#     compareImages <- "test cases failed"
#   }
# } else{
#   compareImages <- "test cases passed"
# }
# number_of_int_tests <- length(result1) + length(result) + length(result2)
# ########################### UI TEST CASES END ###############################



flog.info( knitr::kable(testResults))
flog.info("*************************************************************************************************************")
flog.info("Summary of test cases for this build")
flog.info(knitr::kable(as.data.frame(summary)))

# if(sum(testResults$failed) == 0 && compareImages == "test cases passed"){
if(sum(testResults$failed) == 0) {
  print("All tests passed. Pushing build...")
} else {
  stop()
}

#############################################################################################################
#####                               METRIC COVERAGE REPORTING STARTS                                    #####
#############################################################################################################

######## IMPORTANT!!!! WORKING PATH NEEDS TO BE brick_name/Source/ ###############
library("devtools")

testPackageName<-"testcovr"

sourceFileLocation<-"RegressionUtils.R"
testFIleLocation<-"testCases.R"

# set value according to brick 
# EDA
# Data Wrangling
# Regression
# Classification
# Panel Regression
# Text Mining
# Segmentation
# Quality Check
# SQL

brickName<-"Regression"


##############
# Commented cause aarushi told complex code
##############
total_coverage<-covr::file_coverage(source_files = sourceFileLocation,test_files = testFIleLocation)

total_coverage_data<-as.data.frame(total_coverage)
total_coverage_string<-capture.output(total_coverage,file = NULL,type = "message")

unit_test_coverage_percentage<-"0%"
unit_test_coverage_percentage<-strsplit(total_coverage_string[1],split = ": ")[[1]][2]
#unit_test_coverage_percentage<-paste0(as.character(round(percent_coverage(total_coverage),2)),"%")
# unit_test_coverage<-strsplit(unit_test_coverage_percentage,split = "%")[[1]][1]

#### Deleting the test package
# unlink(testPackageName,recursive = T)

number_of_unit_test<-0
number_of_unit_test<-nrow(testResults)


#### Read Number of lines ####


openedFile <- file("RegressionUtils.R",open="r")
readsizeof <- 20000
lines_of_code<-0
(while((linesread <- length(readLines(openedFile,readsizeof))) > 0 )
  lines_of_code <- lines_of_code+linesread )
close(openedFile)
lines_of_code = as.character(lines_of_code)

##### upload results to DB ######

## Use RPostgreSQL package to connect into database directly and import tables into dataframes.
library("RPostgreSQL")
## loads the PostgreSQL driver
drv <- dbDriver("PostgreSQL")
## Open a l
con <- dbConnect(drv, host='172.25.1.30', port='5432', dbname="metric", user='postgres', password='postgres')


unit_coverage<-unit_test_coverage_percentage
issues<-"0"
number_of_int_tests<-"0"
## lint function is masked by devtools
detach("package:devtools", unload=TRUE)
library("lintr")
warnings_lint<-lint("RegressionUtils.R")
warnings_data_frame <- as.data.frame(warnings_lint)
warnings_list <- as.list(table(warnings_data_frame$type))
issues<-as.character(warnings_list$warning[1])

## Submits a statement
dbSendQuery(con, paste0("INSERT INTO eoc_brick_metrics VALUES (\'",brickName,"\',\'",lines_of_code,"\',\'",number_of_unit_test,"\',\'",issues,"\',\'",number_of_int_tests,"\',\'",unit_test_coverage_percentage,"\');"))

## Closes the connection
dbDisconnect(con)
## Frees all resources in the driver
dbUnloadDriver(drv)

#############################################################################################################
#####                               METRIC COVERAGE REPORTING ENDS                                      #####
#############################################################################################################
# shell script:
# 
#   
#   ls -a
# rm -f *.zip
# #Rscript testCases.R
# if [ $? -eq 0 ]
# then
# echo "Script ran successfully"
# cd Source
# python UpdateBricksVersion.py
# git add 
# version=`cat Description.json | jq '.version' | sed 's/"//g'`
# filename=`cat Description.json | jq '.filename' | sed 's/"//g'`
# fullname=$filename"_v"$version".zip"
# cd ..
# git add *
#   git commit -m "[maven-release-plugin]"
# git tag -a "v"$version -m "Jenkins version update"
# git push git@10.2.2.249:eoc_foundation/04_FoundationBrick_QC.git HEAD:master --follow-tags
# zip -r $fullname ./* -x Source/UpdateBricksVersion.py -x Source/testCases.log -x Source/testCases.R-x JenkinsTestData/\* 
#   #Push to alfresco
#   curl --header 'authorization: Basic Rm91bmRhdGlvbi5Ccmlja3M6TXVzaWdtYUAzNDU=' https://eoc.mu-sigma.com/alfresco/api/-default-/public/alfresco/versions/1/nodes/35b3a4eb-506e-44dc-8742-9bb7ba71d040/content --upload-file $fullname
# curl -H 'Content-Type: application/json' --header 'authorization: Basic Rm91bmRhdGlvbi5Ccmlja3M6TXVzaWdtYUAzNDU=' -X PUT -d '{"name":"'$fullname'"}' https://eoc.mu-sigma.com/alfresco/api/-default-/public/alfresco/versions/1/nodes/35b3a4eb-506e-44dc-8742-9bb7ba71d040
# else
#   echo "Failed"
# fi



# a <- test_file("testCases.R")




# 
# testCounts <- list()
# testCounts[['MAPE Test']][['numerOfTests']] <- 4
# testCounts[['RF Test']][['numerOfTests']] <- 15
# testCounts[['GAM Test']][['numerOfTests']] <- 20
# testCounts[['PDT Test']][['numerOfTests']] <- 15
# testCounts[['xgboost Test']][['numerOfTests']] <- 15
# testCounts[['OLS Test']][['numerOfTests']] <- 10
# testCounts[['stepwise Test']][['numerOfTests']] <- 30
# testCounts[['latentClass Test']][['numerOfTests']] <- 5
# testCounts[['SVR Test']][['numerOfTests']] <- 5
# testCounts[['LARS Test']][['numerOfTests']] <- 20
# testCounts[['LASSO Test']][['numerOfTests']] <- 10
# testCounts[['MARS Test']][['numerOfTests']] <- 5
# testCounts[['PLS Test']][['numerOfTests']] <- 5
# testCounts[['robust Test']][['numerOfTests']] <- 12
# testCounts[['QR Test']][['numerOfTests']] <- 5
# testCounts[['nn Test']][['numerOfTests']] <- 10
# testCounts[['shrinkage Test']][['numerOfTests']] <- 10
