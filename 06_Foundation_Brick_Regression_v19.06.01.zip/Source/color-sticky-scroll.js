$(document).ready(function () {  
  var top = $('#colorGraphsPallete').offset().top;
  $(window).scroll(function (event) {
	var y = $(this).scrollTop();
		if (y >= 168) {
		  $('#colorGraphsPallete').addClass('fixedPalette');
		} else {
		  $('#colorGraphsPallete').removeClass('fixedPalette');
		}
	
  	});
});
