# Title : Regression Analysis
# Created : Apr 11, 2017 10:00 AM
# Author : Jewel James, Vivekanand Mishra, Shreyas Shekar, Ashutosh Singh
# This are the implementation of all the functions that do regression using various algorithms
# packages <- c("mgcv","ggplot2", "MASS","reshape","mRMRe","caret","ranger","htmltools","earth","shrink","ggplot2::ggplot2",
#               "lars","grid","gridExtra","xgboost","MASS","partykit","pls","grid","gtable","edarf",
#               "quantreg","caTools","plyr","visreg","e1071","flexmix","rms","deepnet","glmnet",
#               "qgraph","rqPen")


user_token <- ""
git_url <- "http://mugitlab.mu-sigma.com/api/v3"
project_issue_url <- "http://mugitlab.mu-sigma.com/api/v3/projects/94/issues"
session_url <- "http://mugitlab.mu-sigma.com/api/v3/session"
projectID <- 94


loadGlobals <- function() {
  user_token <<- ""
  git_url <<- "http://mugitlab.mu-sigma.com/api/v3"
  project_issue_url <<- "http://mugitlab.mu-sigma.com/api/v3/projects/94/issues"
  session_url <<- "http://mugitlab.mu-sigma.com/api/v3/session"
  projectID <<- 94
  packages <<- c("reshape","mRMRe","htmltools","earth","shrink","ggplot2",
                 "lars","grid","gridExtra","xgboost","MASS","partykit","pls","gtable","edarf",
                 "quantreg","caTools","mgcv","plyr","visreg","e1071","flexmix","rms","deepnet",
                 "glmnet","qgraph","httr","rjson","shinyBS","colourpicker","compare","devtools",
                 "DT","dplyr","rqPen","caret","ranger","dummies","MLmetrics", "pander", "gtable", "party")
  dbPackages <<- c("rJava","RPostgreSQL","RMySQL","RSQLite","DBI","RJDBC","odbc")
  
  if(file.exists("Source/packageList.csv")){
    packageList <<- read.csv("Source/packageList.csv")
  } else if(file.exists("packageList.csv")){
    packageList <<- read.csv("packageList.csv")
  } else {
    packageList <<- NULL
  }

}

# Regression Functions

vifPlottingFunction <- function(model, color1){
  vifValues <- rms::vif(model)
  vifValues <- as.data.frame(vifValues)
  col1 = rownames(vifValues)
  col2 = round(vifValues[,1],1)
  vifData <- as.data.frame(cbind(col1,col2))
  colnames(vifData) <- c("variableName","VIF")
  vifData$VIF <- as.numeric(vifData$VIF)
  vifVarImp <- vifData[order(vifData$VIF),]
  vifVarImp$Multicollinearity <- factor(ifelse(vifVarImp$VIF < 4,"Low",ifelse(vifVarImp$VIF < 10 , "Medium","High")),
                                        ordered = TRUE)
  
  vifPlot <- ggplot2::ggplot(vifVarImp, ggplot2::aes(x = factor(vifVarImp[,"variableName"], 
                                              levels = vifVarImp[,"variableName"][order(vifVarImp[,"VIF"])]), y = vifVarImp[,"VIF"], fill = Multicollinearity)) + 
    ggplot2::geom_bar(color="white", stat = "identity",position = "dodge", alpha = 0.5) + 
    ggplot2::coord_flip() + ggplot2::ylab("VIF") + ggplot2::xlab("Features") + 
    ggplot2::labs(title= "VIF Plot") + ggplot2::theme(plot.title = ggplot2::element_text(hjust = 0.5)) + 
    ggplot2::geom_hline(yintercept=4,linetype = "dashed" ) +
    ggplot2::geom_hline(yintercept=10, linetype = "dashed" ) + 
    ggplot2::scale_fill_manual("Multi Collinearity", values = c("Low" = "green" ,"Medium" = color1,"High" = "red"))
  return(vifPlot)
}


correlationPlotFunction <- function(corr_data){
  corMat <- base::round(cor(corr_data),3)
  corMat <- reshape2::melt(corMat)
  meltd <- reshape2::melt(corMat, na.rm = T)
  correlationPlot <- ggplot2::ggplot(data = meltd, ggplot2::aes(x = meltd[[1]],y = meltd[[2]],fill = value)) + ggplot2::geom_tile(color = "white") + 
    ggplot2::theme(legend.justification = c(1,0), legend.direction = "vertical", legend.position="vertical") + 
    ggplot2::guides(fill = ggplot2::guide_colorbar( title.position = "top", title.hjust = 0.5)) + 
    ggplot2::scale_fill_gradient2(low = "red", high = "green", mid = "white", midpoint = 0,limit=c(-1,1),
                         space ="Lab", name ="Pearson \nCorrelation") + 
    ggplot2::theme(legend.text = ggplot2::element_text(size = 10, face="bold")) + ggplot2::theme_minimal() + 
    ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 90, vjust = 1, size = 10, hjust = 1, face="bold"),
          plot.margin = grid::unit(c(0,0,0,0), "cm")) + ggplot2::coord_fixed() + ggplot2::xlab("    ") + ggplot2::ylab("   ") + 
    ggplot2::theme(axis.text.y = ggplot2::element_text(angle = 0, vjust = 1, size = 10, hjust = 1, face="bold"), 
          axis.title = ggplot2::element_text(size = 10))+ ggplot2::labs(title= "Correlation Matrix") + 
    ggplot2::theme(plot.title = ggplot2::element_text(hjust = 0.5)) + 
    ggplot2::theme(legend.title = ggplot2::element_text(size=12,face="bold"),legend.text = ggplot2::element_text(size = 10,
                                                                                      face="bold")) 
  
  return(correlationPlot)
}


residualVsFittedPlot <- function(residuals,predicted, color1, color2){
  residualsVspredictedData <- data.frame(residuals=residuals,predicted=predicted)
  ggplot2::ggplot(residualsVspredictedData, ggplot2::aes(x = predicted, y = residuals)) + ggplot2::geom_point(alpha=0.3, colour = color2) + 
    ggplot2::geom_abline(slope = 0,intercept = 0,color=color1,alpha=0.5,linetype="dashed") +
    ggplot2::geom_smooth(color=color1,fill=color1,method = 'loess')+
    ggplot2::xlab("Predicted") + ggplot2::ylab("Residuals")+ ggplot2::ggtitle("Residuals vs Fitted") 
}

residualHistogram <- function(y,yhat, color1)
{
  residuals <- as.numeric(yhat-y)
  plotObj <- ggplot2::qplot(residuals,
                   geom="histogram",
                   binwidth = abs(max(residuals))/10.0,  
                   main = "Histogram of Residuals", 
                   xlab = "Residuals",  
                   ylab = "Count",
                   fill=I(color1), 
                   col=I("white"), 
                   alpha=I(0.5)
  )
  return(plotObj)
}

genericQQ <- function(y,yhat, color1, color2) 
{  
  residuals <- yhat-y
  y <- stats::quantile(residuals, c(0.25, 0.75))
  x <- stats::qnorm(c(0.25, 0.75))
  slope <- diff(y)/diff(x)
  int <- y[1L] - slope * x[1L]
  plotDf <- data.frame(indices = 1:length(residuals), residualsample  = residuals)
  p <- ggplot2::qplot(sample = x, data = data.frame(x=residuals)) + 
    ggplot2::stat_qq(alpha =0.3, colour = color2) +
    ggplot2::geom_abline(slope = slope, intercept = int, color=color1,alpha=0.7,linetype='dashed') +
    ggplot2::ggtitle("Residual distribution vs Normal distribution")
  return(p)
}

actualVsPredictedPlot <- function(actual,predicted, color1, color2){
  actualVsPredictedData <- data.frame(actual=actual,predicted=predicted)
  
  modelMAPE <- mape(y= actual,yhat= predicted)
  
  ggplot2::ggplot(actualVsPredictedData,
         ggplot2::aes(x=predicted,y=actual)) + ggplot2::geom_point(alpha=0.3, colour = color2) +
    ggplot2::geom_smooth(color=color1,fill=color1,method = 'loess')+ ggplot2::xlab("Predicted") +  ggplot2::ylab("Actual") + 
    ggplot2::ggtitle("Actual Response vs Predicted Response.") +
    ggplot2::scale_x_continuous(limits =c(min(actualVsPredictedData$predicted,actualVsPredictedData$actual),
                                 max(actualVsPredictedData$predicted,actualVsPredictedData$actual))) + 
    ggplot2::scale_y_continuous(limits =c(min(actualVsPredictedData$predicted,actualVsPredictedData$actual),
                                 max(actualVsPredictedData$predicted,actualVsPredictedData$actual))) + 
    ggplot2::geom_abline(slope=1, intercept=0,color=color1,alpha=0.5,linetype='dashed')
  
}

mape <- function(y, yhat){
  # Removing actuals that are zero and correspnding predictions as
  # they  interfere with mape calculation
  columnsWithZero <- which(y == 0)
  if(length(columnsWithZero)>0){
    y<- y[-columnsWithZero]
    yhat<- yhat[-columnsWithZero]
  }
  if(length(y)!=length(yhat)){
    warning("Actual and predicted vectors of unequal length. MAPE incorrect.", immediate. = T)
  }
  return(mean(abs((y - yhat)/y))*100)
}

# REGRESSION MODELS

# OLS

OLSFunction <- function(trainingData, testingData, predictedVariable, withIntercept, color1, color2){
  tryCatch({
    # Example of hyperparameter changing
    if (withIntercept){
      OLSFormula <- stats::as.formula(paste0(predictedVariable," ~ ."))
      
    }else{
      OLSFormula <- stats::as.formula(paste0(predictedVariable," ~ . -1"))
    }
    
    # Make your model
    
    OLSModel <- stats::lm(formula = OLSFormula,data= trainingData)
    modelPredictionsTraining <- predict(OLSModel,trainingData)
    
    modelPredictions <- stats::predict(OLSModel,testingData)
    
    OLSTestingMAPE <- mape(y=testingData[,predictedVariable],yhat = modelPredictions)
    OLSTrainingMAPE <- mape(y=trainingData[,predictedVariable],yhat = modelPredictionsTraining)
    summaryMdl <- summary(OLSModel)
    summaryMdl$coefficients[summaryMdl$coefficients[,4]<0.0001,4] <- 0.0001
    summaryMdl$coefficients <- round(summaryMdl$coefficients,4)
    
    ActVsPred <- actualVsPredictedPlot(actual=trainingData[,predictedVariable],
                                       predicted=modelPredictionsTraining, color1 = color1, color2 = color2)
    
    OLSactualVsPredictedComparison <- data.frame(actual = testingData[,predictedVariable],
                                                 predicted = modelPredictions,
                                                 model = paste("OLS ", " MAPE = ",
                                                               round(OLSTestingMAPE,2), "%"),
                                                 id = "OLS")
    # Residual vs fitted plots  
    modf <- ggplot2::fortify(OLSModel)
    modf$studResidual <- stats::rstudent(OLSModel)
    OLSResidualsVsFitted <- residualVsFittedPlot(residuals = (modelPredictionsTraining-trainingData[,predictedVariable]),
                                                 predicted=modelPredictionsTraining, color1 = color1, color2 = color2)
    
    # Residual Histogram
    residualHistogram <- residualHistogram(trainingData[,predictedVariable],modelPredictionsTraining, color1 = color1)
    
    # Q Plot
    
    qPlot <- genericQQ(trainingData[,predictedVariable],modelPredictionsTraining, color1 = color1, color2 = color2)
    
    # ResVsLev
    
    OLSResVsLev <- ggplot2::ggplot(modf, ggplot2::aes(x = .hat, y = .stdresid)) + ggplot2::geom_point(alpha=0.3, colour = color2) + 
      ggplot2::geom_smooth(color=color1,fill=color1,method = 'loess')+
      ggplot2::xlab("Leverage") + ggplot2::ylab("Standardized residuals") +ggplot2::ggtitle("Residuals vs Leverage")+
      ggplot2::geom_hline(yintercept=c(2,-2),color=color1,alpha=0.5,linetype="dashed")
    
    # Studentized Residuals
    
    OLSStudResVsLev <- ggplot2::ggplot(modf, ggplot2::aes(x = .fitted, y = studResidual)) + ggplot2::geom_point(alpha=0.3,colour = color2) + 
      ggplot2::geom_smooth(color=color1,fill=color1,method = 'loess')+
      ggplot2::xlab("Fitted") + ggplot2::ylab("Studentized residuals") +
      ggplot2::geom_hline(yintercept=c(2,-2),color=color1,alpha=0.5,linetype="dashed")+
      ggplot2::ggtitle(paste0("Studentized residuals vs Fitted"))
    
    # VIF Plot
    
    OLSvifPlot <- vifPlottingFunction(OLSModel, color1 = color1)
    
    # Correlation Plot
    
    correlationPlot <- correlationPlotFunction(trainingData)
    
    olsMAPEText <- (paste0("MAPE : ", as.character(round(mape(y =trainingData[,predictedVariable],
                                                              yhat = modelPredictionsTraining ),2)),"%"))
    
    modelFunctionReturn <- list(
      name = "OLS",
      model  = OLSModel,
      summary =  summaryMdl,
      modelPredictionsTesting = modelPredictions,
      modelPredictionsTraining = modelPredictionsTraining,
      trainingMAPE = OLSTrainingMAPE,
      testingMAPE = OLSTestingMAPE,
      ResidualsVsFitted =  OLSResidualsVsFitted,
      residualHistogram = residualHistogram,
      qPlot = qPlot,
      ResVsLev = OLSResVsLev,
      StudResVsLev = OLSStudResVsLev,
      vifPlot = OLSvifPlot,
      correlationPlot = correlationPlot,
      predict = function(model, testDataset){
        return((predict(model,testDataset)))
      },
      olsMAPEText = olsMAPEText,
      actualVsPredictedComparison =  OLSactualVsPredictedComparison,
      ActVsPred = ActVsPred
    )
    remove(
      modelPredictions,
      summaryMdl,
      modelPredictionsTraining,
      OLSResidualsVsFitted,
      OLSTrainingMAPE,
      OLSTestingMAPE,
      residualHistogram,
      qPlot,
      OLSResVsLev,
      OLSStudResVsLev,
      OLSvifPlot,
      olsMAPEText,
      OLSactualVsPredictedComparison,
      ActVsPred
    )
    return(modelFunctionReturn)
    
  },error=function(e){
    modelFunctionReturn <- list(error=as.character(e))
    return(modelFunctionReturn)
    
  }
  )
}


# Stepwise model

StepwiseFunction <- function(trainingData, testingData, predictedVariable, stepWithIntercept, stepDirection, color1, color2){
  tryCatch({
    # Example of hyperparameter changing
    if (stepWithIntercept){
      stepwiseFormula <- stats::as.formula(paste0(predictedVariable," ~ ."))
      
    }else{
      stepwiseFormula <- stats::as.formula(paste0(predictedVariable," ~ . -1"))
    }
    
    # Make your model
    stepwiseModel <- step(stats::lm(formula = stepwiseFormula,data= trainingData),direction = stepDirection)
    modelPredictionsTraining <- predict(stepwiseModel,trainingData)
    modelPredictions <- predict(stepwiseModel,testingData)
    
    stepwiseTrainingMAPE <- mape(y=trainingData[,predictedVariable],yhat = modelPredictionsTraining)
    stepwiseTestingMAPE <<- mape(y=testingData[,predictedVariable],yhat = modelPredictions)
    
    summdl <- summary(stepwiseModel)
    summdl$coefficients[summdl$coefficients[,4]<0.0001,4] <- 0.0001
    summdl$coefficients <- round(summdl$coefficients,4)
    
    stepwiseActualVsPredictedComparison <- data.frame(actual = testingData[,predictedVariable],
                                                      predicted = modelPredictions, model = paste("Stepwise  ", "MAPE = ", round(stepwiseTestingMAPE,2), "%"), id = "stepwise")
    
    # Actual vs Predicted
    
    stepwiseActVsPred <- actualVsPredictedPlot(actual=trainingData[,predictedVariable],
                                               predicted=modelPredictionsTraining, color1 = color1, color2 = color2 )
    
    # Residual vs fitted plots
    
    modf <- ggplot2::fortify(stepwiseModel)
    modf$studResidual <- stats::rstudent(stepwiseModel)
    stepwiseResidualsVsFitted <- residualVsFittedPlot( residuals = (modelPredictionsTraining -trainingData[,predictedVariable]),
                                                       predicted= modelPredictionsTraining, color1 = color1, color2 = color2)
    
    stepwiseResHist <- residualHistogram(trainingData[,predictedVariable],
                                         modelPredictionsTraining, color1= color1)
    
    # Q Plot
    
    stepwiseQPlot <- genericQQ(trainingData[,predictedVariable],modelPredictionsTraining, color1 = color1, color2 = color2)
    
    #Residuals vs leverages
    
    stepwiseResVsLev <- ggplot2::ggplot(modf, ggplot2::aes(x = .hat, y = .stdresid)) + ggplot2::geom_point(alpha=0.3, colour = color2) +
      ggplot2::ggtitle("Residuals vs Leverage")+
      ggplot2::geom_smooth(color=color1,fill=color1,method = 'loess')+
      ggplot2::xlab("Leverage") + ggplot2::ylab("Standardized residuals") +
      ggplot2::geom_hline(yintercept=c(2,-2),color=color1,alpha=0.5,linetype="dashed")
    
    
    #Studentized residuals vs predicted
    
    stepwiseStudResVsLev <- ggplot2::ggplot(modf, ggplot2::aes(x = .fitted, y = studResidual)) + ggplot2::geom_point(alpha=0.3, colour = color2) +
      ggplot2::geom_smooth(color=color1,fill=color1,method = 'loess')+
      ggplot2::xlab("Fitted") + ggplot2::ylab("Studentized residuals") +
      ggplot2::geom_hline(yintercept=c(2,-2),color=color1,alpha=0.5,linetype="dashed")+
      ggplot2::ggtitle(paste0("Studentized residuals vs Fitted"))
    
    # Variance inflation factor
    
    stepWiseVifImpPlot <- vifPlottingFunction(stepwiseModel, color1 = color1)
    stepWiseCorrelationPlot <- correlationPlotFunction(trainingData)
    
    stepwiseMAPEText <- paste0("MAPE : ", as.character(round(stepwiseTrainingMAPE)),"%")
    
    modelFunctionReturn <-  list(
      name = "stepwise",
      model  = stepwiseModel,
      summary = summdl,
      fitted = modelPredictionsTraining,
      trainingMape = stepwiseTrainingMAPE,
      testingPredictions = modelPredictions,
      testingMAPE = stepwiseTestingMAPE,
      predict = function(model, testDataset){
        return(predict(model,testDataset))
      },
      ActVsPred = stepwiseActVsPred,
      ResHist = stepwiseResHist,
      ResidualsVsFitted  =  stepwiseResidualsVsFitted ,
      QPlot = stepwiseQPlot,
      ActualVsPredictedComparison = stepwiseActualVsPredictedComparison,
      ResVsLev = stepwiseResVsLev,
      StudResVsLev =   stepwiseStudResVsLev,
      VifImpPlot =   stepWiseVifImpPlot,
      CorrelationPlot = stepWiseCorrelationPlot,
      MAPEText = stepwiseMAPEText
    )
    remove(summdl,
           modelPredictionsTraining,
           stepwiseTrainingMAPE,
           modelPredictions,
           # stepwiseTestingMAPE,
           stepwiseActVsPred,
           stepwiseResHist,
           stepwiseResidualsVsFitted ,
           stepwiseQPlot,
           stepwiseActualVsPredictedComparison,
           stepwiseResVsLev,
           stepwiseStudResVsLev,
           stepWiseVifImpPlot,
           stepWiseCorrelationPlot,
           stepwiseMAPEText)
    return(modelFunctionReturn)
    
  },error=function(e){
    modelFunctionReturn <- list(error = as.character(e))
    return(modelFunctionReturn)
    
  }
  )
  
}

robustFunction <- function(trainingData, testingData, predictedVariable, robustwithIntercept, color1, color2){
  tryCatch({
    
    # Example of hyperparameter changing
    if (robustwithIntercept){
      robustFormula <- stats::as.formula(paste0(predictedVariable," ~ ."))
      
    }else{
      robustFormula <- stats::as.formula(paste0(predictedVariable," ~ . -1"))
    }
    # Make your model
    
    robustModel <- MASS::rlm(formula = robustFormula, maxit=100,data= trainingData)
    summary <- summary(robustModel)
    modelPredictionsTraining <- predict(robustModel,trainingData)
    robustTrainingMAPE <- mape(y=trainingData[,predictedVariable],yhat = modelPredictionsTraining)
    
    
    modelPredictions <- predict(robustModel,testingData)
    robustTestingMAPE <- mape(y=testingData[,predictedVariable],yhat = modelPredictions)
    
    # Actual vs Predicted
    
    robustActVsPred <- actualVsPredictedPlot(actual=trainingData[,predictedVariable], predicted=modelPredictionsTraining, color1 = color1, color2 = color2)
    
    robustActualVsPredictedComparison <- data.frame(actual = testingData[,predictedVariable], 
                                                    predicted = modelPredictions,
                                                    model = paste("Robust  ", "MAPE = ",
                                                                  round(robustTestingMAPE,2), "%"),
                                                    id = "robust")
    
    # Residual vs fitted plots
    
    modf <- ggplot2::fortify(robustModel)
    modf$studResidual <- stats::rstudent(robustModel)
    
    robustResidualsVsFitted <- residualVsFittedPlot(residuals = (modelPredictionsTraining -trainingData[,predictedVariable]),predicted= modelPredictionsTraining, color1 = color1, color2 = color2)
    robustResHist <- residualHistogram(trainingData[,predictedVariable],modelPredictionsTraining, color1 = color1)
    
    
    # Q plot
    
    robustQPlot <- genericQQ(trainingData[,predictedVariable],modelPredictionsTraining, color1 = color1, color2 = color2)
    
    
    #Studentized residuals vs Fitted
    
    robustStudResVsLev <- ggplot2::ggplot(modf, ggplot2::aes(x = .fitted, y = studResidual)) + ggplot2::geom_point(alpha=0.3, colour = color2) + 
      ggplot2::geom_smooth(color= color1,fill= color1,method = 'loess')+
      ggplot2::xlab("Fitted") + ggplot2::ylab("Studentized residuals") +
      ggplot2::geom_hline(yintercept=c(2,-2),color=color1,alpha=0.5,linetype="dashed") +
      ggplot2::ggtitle(paste0("Studentized residuals vs Fitted"))
    
    # Variance inflation factor
    
    robustVifImpPlot <-  vifPlottingFunction(robustModel, color1 = color1)
    robustCorrelationPlot  <- correlationPlotFunction(trainingData)
    robustMAPEText <- paste0("MAPE : ",as.character(round(mape(y=trainingData[,predictedVariable], yhat=modelPredictionsTraining ),2)),"%")
    
    modelFunctionReturn <-  list(
      name = "robust",
      model  = robustModel,
      summary = summary,
      fitted = modelPredictionsTraining,
      trainingMape = robustTrainingMAPE,
      testingPredictions = modelPredictions,
      testingMAPE = robustTestingMAPE,
      predict = function(model, testDataset){
        return(predict(model,testDataset))
      },
      ActVsPred = robustActVsPred,
      ResHist = robustResHist,
      ResidualsVsFitted  =  robustResidualsVsFitted ,
      qPlot = robustQPlot,
      ActualVsPredictedComparison = robustActualVsPredictedComparison,
      StudResVsLev = robustStudResVsLev,
      VifImpPlot = robustVifImpPlot,
      CorrelationPlot = robustCorrelationPlot,
      MAPEText = robustMAPEText
    )
    remove(summary,
           modelPredictionsTraining,
           robustTrainingMAPE,
           modelPredictions,
           robustTestingMAPE,
           robustActVsPred,
           robustResHist,
           robustResidualsVsFitted ,
           robustQPlot,
           robustActualVsPredictedComparison,
           robustStudResVsLev,
           robustVifImpPlot,
           robustCorrelationPlot,
           robustMAPEText)
    return(modelFunctionReturn)
    
  },error=function(e){
    modelFunctionReturn <- list(error =  as.character(e))
    return(modelFunctionReturn)
    
  }
  )
}


# Random Forest Regression model
RFModelFunction <- function(trainingData, testingData, predictedVariable, RFNoOfTrees, RFmtry, RFMinNodeSize){
  # Make your model
  RFFormula <- (paste0(predictedVariable," ~ ."))
  
  # Make your model
  RFModel <- ranger::ranger(formula = RFFormula,data= trainingData,num.trees = RFNoOfTrees, 
                    mtry=RFmtry, min.node.size= RFMinNodeSize, splitrule= "variance", alpha = 0.5, 
                    minprop = 0.1)
  
  modelPredictionsTraining <- ranger::predictions(predict(RFModel,trainingData))
  modelPredictions <- ranger::predictions(predict(RFModel,testingData))
  
  RFTrainingRMSE <- mean((modelPredictionsTraining - trainingData[,predictedVariable])^2)
  
  RFTrainingMAPE <- mape(y=trainingData[,predictedVariable],yhat = modelPredictionsTraining)
  
  RFTestingRMSE <- mean((modelPredictions - testingData[,predictedVariable])^2)
  
  RFTestingMAPE <- mape(y=testingData[,predictedVariable],yhat = modelPredictions)
  
  actualVsPredicted <- data.frame(predicted= as.numeric(modelPredictionsTraining) ,
                                  actual =  as.numeric(trainingData[,predictedVariable]))
  
  RFActualVsPredictedComparison <- 
    data.frame(actual = testingData[,predictedVariable],predicted = as.numeric(modelPredictions),
               model = paste("RF  ","MAPE = ",                                                                 
                             round(RFTestingMAPE,2), "%"),id = "RF")
  
  residualVsYhat <- data.frame(predicted = as.numeric(modelPredictionsTraining),
                               residual = (as.numeric(modelPredictionsTraining) -
                                             as.numeric(trainingData[,predictedVariable])))
  
  
  # Error vs Accuracy plot
  
  errorAccuracyData <- data.frame(NoOfTrees = numeric(0) , MSE = numeric(0))
  
  RFFormula <- (paste0(predictedVariable," ~ ."))
  
  calculateError <- function(i){
    RFModel <- ranger::ranger(formula = RFFormula,data= trainingData, num.trees = (RFNoOfTrees/3)*i, 
                      mtry=RFmtry, min.node.size= RFMinNodeSize, splitrule= "variance", alpha = 0.5, 
                      minprop = 0.1)
    errorAccuracyData <- rbind(errorAccuracyData, data.frame(NoOfTrees = (RFNoOfTrees/3)*i , MSE = RFModel$prediction.error))
  }
  errorAccuracyData <- sapply(1:3, FUN = calculateError)
  errorAccuracyPlotData <- data.frame(as.numeric(paste(errorAccuracyData[1,])) , as.numeric(paste(errorAccuracyData[2,])))
  colnames(errorAccuracyPlotData) <- rownames(errorAccuracyData)
  modelFunctionReturn <- list(
    name = "RF",
    model  = RFModel,
    pred = modelPredictionsTraining,
    mape = RFTrainingMAPE,
    testingPred = modelPredictions,
    testingMAPE = RFTestingMAPE,
    predict = function(model, testDataset){
      return(ranger::predictions(predict(model,testDataset)))
    },
    
    trainingRMSE = RFTrainingRMSE,
    testingRMSE = RFTestingRMSE,
    actualVsPredicted = actualVsPredicted,
    actualVsPredictedComparison = RFActualVsPredictedComparison,
    residualVsYhat = residualVsYhat,
    
    errorAccuracyPlotData = errorAccuracyPlotData
  )
  remove(modelPredictionsTraining,
         RFTrainingMAPE,
         modelPredictions,
         RFTestingMAPE,
         RFTrainingRMSE,
         RFTestingRMSE,
         actualVsPredicted,
         RFActualVsPredictedComparison,
         residualVsYhat,
         errorAccuracyPlotData)
  return(modelFunctionReturn)
  
}

# Qantile regression model

QRModelFunction <- function(trainingData, testingData, predictedVariable, QRFormula,tau){
  
  # Make your model
  
  QRModel <- quantreg::rq(formula = QRFormula, tau=tau, data= trainingData, method = 'br')
  
  modelPredictionsTraining <- predict(QRModel,trainingData)
  
  QRTrainingRMSE <- mean((modelPredictionsTraining - trainingData[,predictedVariable])^2)
  
  QRTrainingMAPE <- mape(y=trainingData[,predictedVariable],yhat = modelPredictionsTraining)
  
  modelPredictions <- predict(QRModel,testingData)
  
  QRTestingRMSE <- mean((modelPredictions - testingData[,predictedVariable])^2)
  
  QRTestingMAPE <- mape(y=testingData[,predictedVariable],yhat = modelPredictions)
  
  #qrMdlToPrint <- summary(QRModel)
  
  # Plot
  
  actualVsPredicted <- data.frame(predicted= modelPredictionsTraining , actual =  trainingData[,predictedVariable])
  
  QRActualVsPredictedComparison <- data.frame(actual = testingData[,predictedVariable], predicted = modelPredictions,
                                              model = paste("QR  ", "MAPE = ", round(QRTestingMAPE,2), "%"), id = "QR")
  
  residualVsYhat <- data.frame(predicted = modelPredictionsTraining, residual = (modelPredictionsTraining -trainingData[,predictedVariable]))
  
  modelFunctionReturn <- list(
    name = "QR",
    model  = QRModel,
    pred = modelPredictionsTraining,
    mape = QRTrainingMAPE,
    testingPred = modelPredictions,
    testingMAPE = QRTestingMAPE,
    predict = function(model, testDataset){
      return(predict(model,testDataset))
    },
    
    trainingRMSE = QRTrainingRMSE,
    testingRMSE = QRTestingRMSE,
    actualVsPredicted = actualVsPredicted,
    actualVsPredictedComparison = QRActualVsPredictedComparison,
    residualVsYhat = residualVsYhat
    
  )
  remove(modelPredictionsTraining,
         QRTrainingMAPE,
         modelPredictions,
         QRTestingMAPE,
         QRTrainingRMSE,
         QRTestingRMSE,
         actualVsPredicted,
         QRActualVsPredictedComparison,
         residualVsYhat)
  return(modelFunctionReturn)
  
}


# Decision trees regression model

PDTModelFunction <- function(trainingData, testingData, predictedVariable, PDTpValue, PDTminsplit, PDTminbucket){
  PDTFormula <- stats::as.formula(paste0(predictedVariable," ~ ."))
  
  trainingData <- as.data.frame(trainingData)
  
  # Make your model
  
  PDTModel <- partykit::ctree(formula = PDTFormula,data= trainingData, control= partykit::ctree_control(mincriterion = PDTpValue,
                                                                                    minsplit = PDTminsplit,
                                                                                    minbucket = PDTminbucket ))
  
  modelPredictionsTraining <- predict(PDTModel,trainingData)
  modelPredictions <- predict(PDTModel,testingData)
  
  PDTTrainingRMSE <- mean((modelPredictionsTraining - trainingData[,predictedVariable])^2)
  
  PDTTrainingMAPE <- mape(y=trainingData[,predictedVariable],yhat = modelPredictionsTraining)
  
  PDTTestingRMSE <- mean((modelPredictions - testingData[,predictedVariable])^2)
  
  PDTTestingMAPE <- mape(y=testingData[,predictedVariable],yhat = modelPredictions)
  
  actualVsPredicted <- data.frame(predicted= as.numeric(modelPredictionsTraining) ,
                                  actual =  as.numeric(trainingData[,predictedVariable]))
  
  PDTActualVsPredictedComparison <- data.frame(actual = testingData[,predictedVariable],
                                               predicted = as.numeric(modelPredictions), model = paste("PDT  ", "MAPE =", round(PDTTestingMAPE,2), "%"), id = "PDT")
  
  residualVsYhat <- data.frame(predicted = as.numeric(modelPredictionsTraining),
                               residual = (as.numeric(modelPredictionsTraining) -
                                             as.numeric(trainingData[,predictedVariable])))
  
  modelFunctionReturn <- list(
    name = "PDT",
    model  = PDTModel,
    pred = modelPredictionsTraining,
    mape = PDTTrainingMAPE,
    testingPred = modelPredictions,
    testingMAPE = PDTTestingMAPE,
    predict = function(model, testDataset){
      return(predict(model,testDataset))
    },
    
    trainingRMSE = PDTTrainingRMSE,
    testingRMSE = PDTTestingRMSE,
    actualVsPredicted = actualVsPredicted,
    actualVsPredictedComparison = PDTActualVsPredictedComparison,
    residualVsYhat = residualVsYhat
    
  )
  remove(modelPredictionsTraining,
         PDTTrainingMAPE,
         modelPredictions,
         PDTTestingMAPE,
         PDTTrainingRMSE,
         PDTTestingRMSE,
         actualVsPredicted,
         PDTActualVsPredictedComparison,
         residualVsYhat)
  return(modelFunctionReturn)
  
}

# Support vector regression model

SVRModelFunction <- function(trainingData, testingData, predictedVariable){
  # Formula
  SVRFormula <- stats::as.formula(paste0(predictedVariable," ~ ."))
  
  # Making sure predicted value is numeric
  trainingData[,predictedVariable] <- as.numeric(trainingData[,predictedVariable])
  
  # Make your model
  
  SVRModel <- e1071::svm(SVRFormula,data= trainingData)
  
  modelPredictionsTraining <- predict(SVRModel,trainingData)
  
  modelPredictions <- predict(SVRModel,testingData)
  
  SVRTrainingRMSE <- mean((modelPredictionsTraining - trainingData[,predictedVariable])^2)
  
  SVRTrainingMAPE <- mape(y=trainingData[,predictedVariable],yhat = modelPredictionsTraining)
  
  SVRTestingRMSE <- mean((modelPredictions - testingData[,predictedVariable])^2)
  
  SVRTestingMAPE <- mape(y=testingData[,predictedVariable],yhat = modelPredictions)
  
  # Plot
  
  actualVsPredicted <- data.frame(predicted= modelPredictionsTraining , actual =  trainingData[,predictedVariable])
  
  residualVsYhat <- data.frame(predicted = modelPredictionsTraining, residual = (modelPredictionsTraining -trainingData[,predictedVariable]))
  
  SVRActualVsPredictedComparison <- data.frame(actual = testingData[,predictedVariable], predicted = modelPredictions,
                                               model = paste("SVR  ", "MAPE = ", round(SVRTestingMAPE,2), "%"), id = "SVR")
  
  modelFunctionReturn <- list(
    name = "SVR",
    model  = SVRModel,
    pred = modelPredictionsTraining,
    mape = SVRTrainingMAPE,
    testingPred = modelPredictions,
    testingMAPE = SVRTestingMAPE,
    predict = function(model, testDataset){
      return(predict(model,testDataset))
    },
    
    trainingRMSE = SVRTrainingRMSE,
    testingRMSE = SVRTestingRMSE,
    actualVsPredicted = actualVsPredicted,
    actualVsPredictedComparison = SVRActualVsPredictedComparison,
    residualVsYhat = residualVsYhat
    
  )
  remove(modelPredictionsTraining,
         SVRTrainingMAPE,
         modelPredictions,
         SVRTestingMAPE,
         SVRTrainingRMSE,
         SVRTestingRMSE,
         actualVsPredicted,
         SVRActualVsPredictedComparison,
         residualVsYhat)
  return(modelFunctionReturn)
  
}


# PLS regression model

PLSModelFunction <- function(trainingData, testingData, predictedVariable){
  
  # Formula
  PLSFormula <- stats::as.formula(paste0(predictedVariable," ~ ."))
  
  # Selecting number of components for pls
  PLSModelTemp <- pls::plsr(PLSFormula, data=trainingData, validation = "CV")
  nComponents <- pls::selectNcomp(PLSModelTemp, method = c("onesigma"))
  
  # Make your model
  PLSModel <- pls::plsr(PLSFormula, data=trainingData, ncomp = nComponents, validation = "LOO")
  modelPredictionsTraining <- predict(PLSModel,ncomp = nComponents, newdata = trainingData)
  modelPredictions <- predict(PLSModel, newdata = testingData, ncomp = nComponents)
  PLSTrainingRMSE <- mean((modelPredictionsTraining - trainingData[,predictedVariable])^2)
  PLSTrainingMAPE <- mape(y=trainingData[,predictedVariable],yhat = modelPredictionsTraining)
  PLSTestingRMSE <- mean((modelPredictions - testingData[,predictedVariable])^2)
  PLSTestingMAPE <- mape(y=testingData[,predictedVariable],yhat = modelPredictions)
  
  
  actualVsPredicted <- data.frame(predicted= as.numeric(modelPredictionsTraining), 
                                  actual =  as.numeric(trainingData[,predictedVariable]))
  
  PLSActualVsPredictedComparison <- data.frame(actual = testingData[,predictedVariable],
                                               predicted = as.numeric(modelPredictions),
                                               model = paste("PLS  ", "MAPE = ", round(PLSTestingMAPE,2), "%"),
                                               id = "PLS" )
  
  residualVsYhat <- data.frame(predicted = as.numeric(modelPredictionsTraining),
                               residual = (as.numeric(modelPredictionsTraining)
                                           -as.numeric(trainingData[,predictedVariable])))
  
  modelFunctionReturn <- list(
    name = "PLS",
    model  = PLSModel,
    pred = modelPredictionsTraining,
    mape = PLSTrainingMAPE,
    testingPred = modelPredictions,
    testingMAPE = PLSTestingMAPE,
    predict = function(model, testDataset){
      nComponentsModel <- PLSModel$ncomp
      return(predict(model,testDataset, ncomp = nComponentsModel))
    },
    
    trainingRMSE = PLSTrainingRMSE,
    testingRMSE = PLSTestingRMSE,
    actualVsPredicted = actualVsPredicted,
    actualVsPredictedComparison = PLSActualVsPredictedComparison,
    residualVsYhat = residualVsYhat,
    
    nComponents = nComponents
    
  )
  remove(modelPredictionsTraining,
         PLSTrainingMAPE,
         modelPredictions,
         PLSTestingMAPE,
         PLSTrainingRMSE,
         PLSTestingRMSE,
         actualVsPredicted,
         PLSActualVsPredictedComparison,
         residualVsYhat,
         nComponents)
  return(modelFunctionReturn)
  
}


# XGBoost regression model

xgboostModelFunction <- function(trainingData, testingData, predictedVariable, xgboostMaxDepth, xgboostLeraningRate, 
                                 xgboostNoOfIterations){
  xgboostData <- trainingData[,!(names(trainingData) %in% predictedVariable)]
  output_vector <-trainingData[,predictedVariable]
  
  # xgboostData[] <- lapply(xgboostData, as.numeric)
  
  # xgboostData
  numericNewData <- sapply(xgboostData, function(x) as.numeric(x) )
  xgboostModel <- xgboost::xgboost(data = as.matrix(numericNewData),
                          label = output_vector,
                          max.depth = xgboostMaxDepth,
                          eta = xgboostLeraningRate,
                          nround = xgboostNoOfIterations,
                          objective = "reg:linear",
                          #num_class = length(unique(output_vector)),
                          verbose = 1, save_period = NULL
  )
  
  # # Use the below line to predict on the test dataset
  xgboostTrainData <- trainingData[,!(names(trainingData) %in% predictedVariable)]
  label <- trainingData[,predictedVariable]
  # modelPredictionsTraining <- predict(xgboostModel,as.matrix(xgboostTrainData))
  modelPredictionsTraining <- predict(xgboostModel,as.matrix(xgboostTrainData))
  xgboostTrainingRMSE <- mean((modelPredictionsTraining - trainingData[,predictedVariable])^2)
  xgboostTrainingMAPE <- mape(y=trainingData[,predictedVariable],yhat = modelPredictionsTraining)
  
  xgboostTestData <- testingData[,!(names(testingData) %in% predictedVariable)]
  label <- testingData[,predictedVariable]
  modelPredictions <- predict(xgboostModel,as.matrix(xgboostTestData))
  xgboostTestingRMSE <- mean((modelPredictions - testingData[,predictedVariable])^2)
  xgboostTestingMAPE <- mape(y=testingData[,predictedVariable],yhat = modelPredictions)
  
  
  
  actualVsPredicted <- data.frame(predicted= modelPredictionsTraining , actual =  trainingData[,predictedVariable])
  
  residualVsYhat <- data.frame(predicted = modelPredictionsTraining, residual = (modelPredictionsTraining -trainingData[,predictedVariable]))
  # Actual vs Predicted
  
  
  
  xgboostActualVsPredictedComparison <- data.frame(actual = testingData[,predictedVariable],
                                                   predicted = modelPredictions,
                                                   model = paste("xgboost  ","MAPE = ",
                                                                 round(xgboostTestingMAPE,2), "%"),id = "XG")
  
  modelFunctionReturn <- list(
    name = "xgboost",
    model  = xgboostModel,
    pred = modelPredictionsTraining,
    mape = xgboostTrainingMAPE,
    testingPred = modelPredictions,
    testingMAPE = xgboostTestingMAPE,
    predict = function(model, testDataset){
      return(predict(model,as.matrix(testDataset)))
    },
    
    trainingRMSE = xgboostTrainingRMSE,
    testingRMSE = xgboostTestingRMSE,
    actualVsPredicted = actualVsPredicted,
    actualVsPredictedComparison = xgboostActualVsPredictedComparison,
    residualVsYhat = residualVsYhat
    
  )
  remove(modelPredictionsTraining,
         xgboostTrainingMAPE,
         modelPredictions,
         xgboostTestingMAPE,
         xgboostTrainingRMSE,
         xgboostTestingRMSE,
         actualVsPredicted,
         xgboostActualVsPredictedComparison,
         residualVsYhat)
  return(modelFunctionReturn)
  
}





# GAM Regression

gamFunction <- function(trainingData, predictedVariable, smoothListCol, gamWithIntercept, testingData, color1, color2 ){
  tryCatch({
    gamTrainingData <- as.data.frame(trainingData[, -which(colnames(trainingData) %in% predictedVariable)])
    colnames(gamTrainingData) <- colnames(trainingData)[-which(colnames(trainingData) %in% predictedVariable)]
    
    # Columns to be applied a smoothening parameter must be seperated in formula
    
    colToRemove <- as.character(smoothListCol)
    if(length(colToRemove) != 0){
      gamTrainingData <- gamTrainingData[, -which(colnames(gamTrainingData) %in% colToRemove),drop = FALSE]
      
      col <- paste("s(",smoothListCol,")+",sep = '',collapse = '')
      colToSmooth <- substr(col,1,nchar(col)-1)
    }else{
      colToSmooth <- c()}
    # Columns on which smoothening parameter must not be applied  
    
    nonSmoothPredictor<- paste(colnames(gamTrainingData),collapse = "+")
    
    if(length(colnames(gamTrainingData))==0){
      dependentVariable <-colToSmooth
    }else{
      dependentVariable <- paste(c(colToSmooth,nonSmoothPredictor), collapse = "+" )
    }
    
    # Example of hyperparameter changing
    
    if (gamWithIntercept){
      gamFormula <- stats::as.formula(paste0(predictedVariable,"~",dependentVariable))
    }else{
      gamFormula <- stats::as.formula(paste0(predictedVariable, "~", "-1 + ", dependentVariable))}
    
    # Make your model
    gamModel <- mgcv::gam(formula = gamFormula, data= trainingData)
    summary <- summary(gamModel)
    modelPredictionsTraining <- predict(gamModel,trainingData)
    modelPredictions <- predict(gamModel,testingData)
    gamTrainingMAPE <- mape(y=trainingData[,predictedVariable],yhat = modelPredictionsTraining)
    gamTestingMAPE <- mape(y=testingData[,predictedVariable],yhat = modelPredictions)
    
    # Actual Vs Comparison 
    
    gamActualVsPredictedComparison <- data.frame(actual = testingData[,predictedVariable],
                                                 predicted = unname(modelPredictions),
                                                 model = paste("GAM  ", "MAPE = ", round(gamTestingMAPE,2), "%"),
                                                 id = "GAM")
    
    # Actual vs Predicted plot
    
    gamActualVsPredictedPlot <- actualVsPredictedPlot(actual= trainingData[,predictedVariable], 
                                                      predicted = modelPredictionsTraining, color1 = color1, color2 = color2)
    
    # Residual vs Fitted plot 
    
    gamResidualsVsFitted <- residualVsFittedPlot(residuals=trainingData[,predictedVariable]- modelPredictionsTraining,
                                                 predicted = modelPredictionsTraining, color1 = color1, color2 = color2)
    
    # Q-Q Plot
    
    gamQPlot <-  genericQQ(y=trainingData[,predictedVariable],yhat = modelPredictionsTraining, color1 = color1, color2 = color2 )
    
    #Residuals vs leverages
    
    dataResLev <- data.frame(std.resid = ((gamModel$residuals)/sd(gamModel$residuals)))
    dataResLev$hat <- mgcv::influence.gam(gamModel) # Hat matrix in R
    gamResVsLev <- ggplot2::ggplot(dataResLev, ggplot2::aes(x = hat, y = std.resid)) +
      ggplot2::geom_point(alpha=0.3,colour = color2) +  ggplot2::geom_smooth(color=color1,fill=color1,method = 'loess') +
      ggplot2::xlab("Leverage") + ggplot2::ylab("Standardized residuals") + ggplot2::ggtitle("Residuals vs Leverage")+
      ggplot2::geom_hline(yintercept=c(2,-2),color=color1,alpha=0.5,linetype="dashed")
    
    
    #Studentized residuals vs Fitted
    
    predictY <- trainingData[ , which(names(trainingData) %in% predictedVariable)]
    
    sE <- sqrt(sum((predictY -gamModel$fitted.values)^2)/nrow(gamTrainingData))
    
    denominator <- sqrt(1-dataResLev$hat) * sE
    numerator <- predictY - gamModel$fitted.values
    standardizedResiduals <- numerator/denominator
    
    studentizedResiduals <- 
      sqrt((nrow(gamTrainingData) - ncol(gamTrainingData) - 2)/(nrow(gamTrainingData) - ncol(gamTrainingData) - 
                                                                  1 - (standardizedResiduals))) * standardizedResiduals
    
    
    studentData <- data.frame(fitted = gamModel$fitted.values , studResidual = studentizedResiduals)
    
    StudResVsLev <- ggplot2::ggplot(studentData, ggplot2::aes(x = fitted, y = studResidual)) + ggplot2::geom_point(alpha=0.3, colour = color2) + 
      ggplot2::geom_smooth(color=color1,fill=color1,method = 'loess')+
      ggplot2::xlab("Fitted") + ggplot2::ylab("Studentized residuals") +ggplot2::ggtitle("Residuals vs Leverage")+
      ggplot2::geom_hline(yintercept=c(2,-2),color=color1,alpha=0.5,linetype="dashed") +
      ggplot2::ggtitle(paste0("Studentized residuals vs Fitted"))
    
    # Residual Histogram
    
    gamResHist <- residualHistogram(trainingData[,predictedVariable],modelPredictionsTraining, color1 = color1)
    
    # MAPE Text
    
    gamMAPEText <- paste0("MAPE : ",as.character(round(as.numeric(gamTrainingMAPE,2))),"%")
    
    ## Smooth plots
    #Courtesy http://stackoverflow.com/questions/19735149/is-it-possible-to-plot-the-smooth-components-of-a-gam-fit-with-ggplot2
    
    
    if(length(colToRemove) != 0){
      
      plotData <- visreg::visreg(gamModel, type = "contrast", plot = FALSE)
      
      
      if(length(colToRemove) == 1){
        smooths <- data.frame(variable = plotData$meta$x,             
                              x=plotData$fit[[plotData$meta$x]],             
                              smooth=plotData$fit$visregFit,             
                              lower=plotData$fit$visregLwr,             
                              upper=plotData$fit$visregUpr)  
      }            
      else{            
        smooths <- plyr::ldply(plotData, function(part)               
          data.frame(variable = part$meta$x,             
                     x=part$fit[[part$meta$x]],             
                     smooth=part$fit$visregFit,             
                     lower=part$fit$visregLwr,             
                     upper=part$fit$visregUpr))            
      }                     
      smooths <- smooths[(smooths$variable %in% colToRemove),]
      plotDataNative <- plot( gamModel, pages = 1, col = color1)
      plotDataNativeClean <- data.frame(raw = numeric(0), yDummy = numeric(0), variable = character(0))
      
      for (i in 1:length(plotDataNative)){
        raw = plotDataNative[[i]]$raw
        yDummy = 1
        variable = plotDataNative[[i]]$xlab
        tempData <- data.frame(raw = raw, yDummy = yDummy , variable = variable)
        plotDataNativeClean <- rbind(plotDataNativeClean, tempData)
      }
      
      
      gamSmoothCurve <- ggplot2::ggplot(smooths, ggplot2::aes(x, smooth)) + ggplot2::geom_line() +
        ggplot2::geom_line(ggplot2::aes(y=lower), linetype="dashed" , col= color1) +
        ggplot2::geom_line(ggplot2::aes(y=upper), linetype="dashed" , col= color1) +
        ggplot2::geom_rug(data = plotDataNativeClean,ggplot2::aes(raw , yDummy), sides="b") +
        ggplot2::facet_wrap( ~ variable, scales="free")
      
    }else{
      gamSmoothCurve <- NULL
    }
    
    modelFunctionReturn <-  list(
      name = "GAM",
      model  = gamModel,
      summary = summary,
      fitted = modelPredictionsTraining,
      trainingMAPE = gamTrainingMAPE,
      testingPredictions = modelPredictions,
      testingMAPE = gamTestingMAPE ,
      predict = function(model, testDataset){
        return(predict(model,testDataset))
      },
      ActVsPred = gamActualVsPredictedPlot,
      ResVsLev = gamResVsLev,
      ResHist = gamResHist,
      ResidualsVsFitted  = gamResidualsVsFitted,
      qPlot = gamQPlot,
      ActualVsPredictedComparison = gamActualVsPredictedComparison,
      StudResVsLev = StudResVsLev,
      MAPEText = gamMAPEText,
      smoothCurve = gamSmoothCurve
    )
    remove(summary,
           modelPredictionsTraining,
           gamTrainingMAPE,
           modelPredictions,
           gamTestingMAPE ,
           gamActualVsPredictedPlot,
           gamResVsLev,
           gamResHist,
           gamResidualsVsFitted,
           gamQPlot,
           gamActualVsPredictedComparison,
           StudResVsLev,
           gamMAPEText,
           gamSmoothCurve)
    return(modelFunctionReturn)
    
  },error=function(e){
    modelFunctionReturn <- list(error = as.character(e))
    return(modelFunctionReturn)
    
  }
  )
}





shrinkageModelFunction <- function(trainingData, testingData, predictedVariable){
  tryCatch({
    shrinkageFormula <- stats::as.formula(paste0(predictedVariable," ~ ."))
    lmfit <- lm(formula = shrinkageFormula,data= trainingData, x = T, y = T)
    # linDepColsInModel <- names(lmfit$coefficients[which(is.na(lmfit$coefficients) == TRUE)])
    # if(length(linDepColsInModel) > 0){
    #   stop("The dataset has linearly dependent features")
    # }
    shrinkageModel <- shrink::shrink(lmfit, type = "global", method = "dfbeta")
    trainInput <- trainingData[,!(names(trainingData)) %in% c(predictedVariable)]
    modelPredictionsTraining <- (shrinkageModel$ShrunkenRegCoef[-(1:1)]%*%t( trainInput) ) + shrinkageModel$ShrunkenRegCoef[1]
    shrinkageTrainingMAPE <- mape(y=trainingData[,predictedVariable],yhat = t(modelPredictionsTraining))
    testInput <- testingData[,!(names(testingData)) %in% c(predictedVariable)]
    modelPredictions <- (shrinkageModel$ShrunkenRegCoef[-(1:1)]%*%t(testInput) ) + shrinkageModel$ShrunkenRegCoef[1]
    shrinkageTestingMAPE <- mape(y=testingData[,predictedVariable],yhat = t(modelPredictions)) 
    actualVsPred <- data.frame(actual=trainingData[,predictedVariable],
                               predicted=t(modelPredictionsTraining))
    shrinkageActualVsPredictedComparison <-
      data.frame(
        actual = testingData[, predictedVariable],
        predicted = t(modelPredictions),
        model = paste("Shrinkage  ",
                      "MAPE = ",
                      round(shrinkageTestingMAPE, 2), "%"),
        id = "shrinkage"
      )
    residualVsYhat <- data.frame(predicted = t(modelPredictionsTraining), residual = (t(modelPredictionsTraining) -trainingData[,predictedVariable]))
    
    
    modelFunctionReturn <- list(
      name = "shrinkage",
      model  = shrinkageModel,
      pred = t(modelPredictionsTraining),
      mape = shrinkageTrainingMAPE,
      testingPred = t(modelPredictions),
      testingMAPE = shrinkageTestingMAPE,
      predict = function(model, testDataset){
        Input <- testDataset
        Predictions <- (model$ShrunkenRegCoef[-(1:1)]%*%t(Input) ) + model$ShrunkenRegCoef[1]
        return(t(Predictions))
      },
      
      actualVsPredicted = actualVsPred,
      actualVsPredictedComparison = shrinkageActualVsPredictedComparison,
      residualVsYhat = residualVsYhat
      
    )
    remove(modelPredictionsTraining,
           shrinkageTrainingMAPE,
           modelPredictions,
           shrinkageTestingMAPE,
           actualVsPred,
           shrinkageActualVsPredictedComparison,
           residualVsYhat)
    return(modelFunctionReturn)
  },error = function(e){
    modelFunctionReturn <- list(error = paste0("Shrinkage regression Failed",as.character(e)))
  })
}

larsModelFunction <- function(trainingData, testingData, predictedVariable, larsWithIntercept){
  tryCatch({
    if (larsWithIntercept){
      LARSModel <- lars(data.matrix(trainingData[,!(names(trainingData) %in% c(predictedVariable))]), data.matrix(trainingData[,predictedVariable]),intercept = T)
      
    }else{
      LARSModel <- lars(data.matrix(trainingData[,!(names(trainingData) %in% c(predictedVariable))]), data.matrix(trainingData[,predictedVariable]), intercept = F)
    }
    larsAfterPredict <- predict(LARSModel,data.matrix(trainingData[,!(names(trainingData) %in% c(predictedVariable))]))
    modelPredictionsTraining <- larsAfterPredict$fit[,dim(larsAfterPredict$fit)[2]]
    LARSTrainingMAPE <- mape(y=trainingData[,predictedVariable],yhat = modelPredictionsTraining)
    
    larsAfterPredictTest <- predict(LARSModel,data.matrix(testingData[,!(names(trainingData) %in% c(predictedVariable))]))
    larsAfterPredictTestData <- larsAfterPredictTest$fit[,dim(larsAfterPredictTest$fit)[2]]
    LARSTestingMAPE <<- mape(y=testingData[,predictedVariable],yhat = larsAfterPredictTestData)
    
    actualVsPred <- data.frame(actual=trainingData[,predictedVariable],
                               predicted=modelPredictionsTraining)
    LARSActualVsPredictedComparison <-
      data.frame(
        actual = testingData[, predictedVariable],
        predicted = larsAfterPredictTestData,
        model = paste("LARS  ",
                      "MAPE = ",
                      round(LARSTestingMAPE, 2),
                      "%"),
        id = "LARS"
      ) 
    
    residualVsYhat <- data.frame(predicted = modelPredictionsTraining, residual = (modelPredictionsTraining -trainingData[,predictedVariable]))
    
    modelFunctionReturn <- list(
      name = "LARS",
      model  = LARSModel,
      pred = modelPredictionsTraining,
      mape = LARSTrainingMAPE,
      testingPred = larsAfterPredictTestData,
      testingMAPE = LARSTestingMAPE,
      predict = function(model, testDataset){
        larsAfterPredict <- predict(model,data.matrix(testDataset))
        return(larsAfterPredict$fit[,dim(larsAfterPredict$fit)[2]])
      },
      
      actualVsPredicted = actualVsPred,
      actualVsPredictedComparison = LARSActualVsPredictedComparison,
      residualVsYhat = residualVsYhat
      
    )
    remove(modelPredictionsTraining,
           LARSTrainingMAPE,
           larsAfterPredictTestData,
           LARSTestingMAPE,
           actualVsPred,
           LARSActualVsPredictedComparison,
           residualVsYhat)
    return(modelFunctionReturn)
  },error = function(e){
    modelFunctionReturn <- list(error = paste0("LARS regression Failed",as.character(e)))
  })
}



AdaptiveLASSOModelFunction <- function(trainingData, testingData, predictedVariable, larsWithIntercept,alpha){
  #tryCatch({
    if (larsWithIntercept){
      lasso1 <- glmnet::cv.glmnet(data.matrix(trainingData[, !(names(trainingData) %in% c(predictedVariable)), drop =
                                                     FALSE]),
                          data.matrix(trainingData[, predictedVariable]))
      w3=(abs(coef(lasso1)[-1])+1/nrow(data.matrix(trainingData[, !(names(trainingData) %in% c(predictedVariable)), drop =
                                                                  FALSE])))^(-1)
      AdaptiveLASSOModel <-
        glmnet::glmnet(
          data.matrix(trainingData[, !(names(trainingData) %in% c(predictedVariable)), drop =
                                     FALSE]),
          data.matrix(trainingData[, predictedVariable]) ,
          penalty.factor = w3,
          alpha = alpha,
          standardize = TRUE,
          intercept = TRUE
        )
      
    }else{
      lasso1 <- glmnet::cv.glmnet(data.matrix(trainingData[, !(names(trainingData) %in% c(predictedVariable)), drop =
                                                     FALSE]),
                          data.matrix(trainingData[, predictedVariable]))
      w3=(abs(coef(lasso1)[-1])+1/nrow(data.matrix(trainingData[, !(names(trainingData) %in% c(predictedVariable)), drop =
                                                                  FALSE])))^(-1)
      AdaptiveLASSOModel <-
        glmnet::glmnet(
          data.matrix(trainingData[, !(names(trainingData) %in% c(predictedVariable)), drop =
                                     FALSE]),
          data.matrix(trainingData[, predictedVariable]) ,
          penalty.factor = w3,
          alpha = alpha,
          standardize = TRUE,
          intercept = FALSE
        )
    } 
    AdaptiveLASSOPredictionsTraining <-
      predict(AdaptiveLASSOModel,
              newx = data.matrix(trainingData[, !(names(trainingData) %in% c(predictedVariable))]),
              s = c(0.005))[,1]
    AdaptiveLASSOPredictions <-
      predict(AdaptiveLASSOModel,
              newx = data.matrix(testingData[, !(names(trainingData) %in% c(predictedVariable))]),
              s = c(0.005))[,1]
    
    AdaptiveLASSOMAPE <- mape(y=testingData[,predictedVariable],yhat = AdaptiveLASSOPredictions)
    AdaptiveLASSOMAPETraining <- mape(y=trainingData[,predictedVariable],yhat = AdaptiveLASSOPredictionsTraining)
    
    actualVsPred <- data.frame(actual=trainingData[,predictedVariable],
                               predicted=AdaptiveLASSOPredictionsTraining)
    
    AdaptiveLASSOActualVsPredictedComparison <-
      data.frame(
        actual = testingData[, predictedVariable],
        predicted = AdaptiveLASSOPredictions,
        model = paste("AdaptiveLASSO  ",
                      "MAPE = ",
                      round(AdaptiveLASSOMAPE, 2),
                      "%"),
        id = "AdaptiveLASSO"
      ) 
    
    residualVsYhat <-
      data.frame(
        predicted = AdaptiveLASSOPredictionsTraining,
        residual = (AdaptiveLASSOPredictionsTraining - trainingData[, predictedVariable])
      )
    
    
    modelFunctionReturn <- list(
      name = "AdaptiveLASSO",
      model  = AdaptiveLASSOModel,
      pred = AdaptiveLASSOPredictionsTraining,
      mape = AdaptiveLASSOMAPETraining,
      testingPred = AdaptiveLASSOPredictions,
      testingMAPE = AdaptiveLASSOMAPE,
      predict = function(model, testDataset) {
        return(predict(
          model,
          newx = data.matrix(testDataset),
          s = c(0.005)
        )[, 1])
      },
      
      actualVsPredicted = actualVsPred,
      actualVsPredictedComparison = AdaptiveLASSOActualVsPredictedComparison,
      residualVsYhat = residualVsYhat
      
    )
    remove(AdaptiveLASSOPredictionsTraining,
           AdaptiveLASSOMAPETraining,
           AdaptiveLASSOPredictions,
           AdaptiveLASSOMAPE,
           actualVsPred,
           AdaptiveLASSOActualVsPredictedComparison,
           residualVsYhat)
    return(modelFunctionReturn)
  # },error = function(e){
  #   
  #   modelFunctionReturn <- list(error = paste0("AdaptiveLASSO regression Failed",as.character(e)))
  #   print(modelFunctionReturn)
  # })
}



marsModelFunction <- function(trainingData, testingData, predictedVariable){
  
  tryCatch({
    MARSFormula <- stats::as.formula(paste0(predictedVariable," ~ ."))
    MARSModel <- earth::earth(formula = MARSFormula,data= trainingData)
    modelPredictionsTraining <- predict(MARSModel,trainingData)
    modelPredictions <- predict(MARSModel,testingData)
    
    MARSTrainingMAPE <- mape(y=trainingData[,predictedVariable],yhat = modelPredictionsTraining[,1])
    MARSTestingMAPE <- mape(y=testingData[,predictedVariable],yhat = modelPredictions[,1])
    
    actualVsPredicted <- data.frame(predicted= modelPredictionsTraining[,1] ,
                                    actual =  trainingData[,predictedVariable])
    MARSActualVsPredictedComparison <-
      data.frame(
        actual = testingData[,predictedVariable],
        predicted = modelPredictions[, 1],
        model = paste("MARS  ", "MAPE = ",
                      round(MARSTestingMAPE, 2), "%"),
        id = "MARS"
      )
    
    residualVsYhat <-
      data.frame(
        predicted = modelPredictionsTraining,
        residual = (modelPredictionsTraining - trainingData[, predictedVariable])
      )
    
    modelFunctionReturn <- list(
      name = "MARS",
      model  = MARSModel,
      pred = modelPredictionsTraining[,1],
      mape = MARSTrainingMAPE,
      testingPred = modelPredictions[,1],
      testingMAPE = MARSTestingMAPE,
      predict = function(model, testDataset){
        return(predict(model,testDataset)[,1])
      },
      
      actualVsPredicted = actualVsPredicted,
      actualVsPredictedComparison = MARSActualVsPredictedComparison,
      residualVsYhat = residualVsYhat
      
    )
    remove(modelPredictionsTraining,
           MARSTrainingMAPE,
           modelPredictions,
           MARSTestingMAPE,
           actualVsPredicted,
           MARSActualVsPredictedComparison,
           residualVsYhat)
    return(modelFunctionReturn)
  },error = function(e){
    modelFunctionReturn <- list(error = paste0("XGBoost regression Failed",as.character(e)))
  })
}



flexmixModelFunction <- function(trainingData, testingData, predictedVariable){
  tryCatch({
    set.seed(7)
    x <- data.frame(trainingData[,!(names(trainingData) %in% predictedVariable)])
    colnames(x) <- colnames(trainingData)[which(!(names(trainingData) %in% predictedVariable))]
    y <- as.character(predictedVariable)
    trainingDataLatent <- data.frame(trainingData[,!(names(trainingData) %in% predictedVariable)])
    colnames(trainingDataLatent) <- colnames(trainingData)[which(!(names(trainingData) %in% predictedVariable))]
    testingDataLatent <- data.frame(testingData[,!(names(testingData) %in% predictedVariable)])
    colnames(testingDataLatent) <- colnames(testingData)[which(!(names(testingData) %in% predictedVariable))]
    
    # predictFlexmix <- function(modelObject,newData){
    #   latentCluster <- clusters(modelObject,newdata = newData)
    #   latentScores <- as.data.frame(predict(modelObject, newdata=newData))
    #   predictedVector <- sapply(1:length(latentCluster),FUN = function(x)latentScores[x,latentCluster[x]])
    #   return(predictedVector)
    # }
    
    stepflexmixModel <- flexmix::stepFlexmix(stats::as.formula(paste0(predictedVariable," ~ .")), 
                                    nrep = 5, 
                                    k = 1:5, 
                                    data = trainingData,
                                    drop=FALSE, 
                                    unique=FALSE,
                                    control = list(iter = 1000,tol = 1e-08, verbose = 0)
    )
    
    flexmixModel <- flexmix::getModel(stepflexmixModel, which = "BIC")
    refitFlexmixModel <- flexmix::refit(flexmixModel)
    modelPredictionsTraining <- flexmix::predict(flexmixModel,trainingData, aggregate = TRUE)[[1]][,1]
    modelPredictions <- flexmix::predict(flexmixModel,testingData, aggregate = TRUE)[[1]][,1]
    flexmixTrainingMAPE <- mape(y=trainingData[,predictedVariable],yhat = modelPredictionsTraining)
    flexmixTestingMAPE <- mape(y=testingData[,predictedVariable],yhat = modelPredictions)
    
    actualVsPredicted <- data.frame(predicted=modelPredictionsTraining , actual=trainingData[,predictedVariable])
    flexmixActualVsPredictedComparison <-
      data.frame(
        actual = testingData[, predictedVariable],
        predicted = modelPredictions,
        model = paste("Latent Class  ", "MAPE = ",
                      round(flexmixTestingMAPE, 2), "%"),
        id = "Latent"
      )
    
    residualVsYhat <-
      data.frame(
        predicted = modelPredictionsTraining,
        residual = (modelPredictionsTraining - trainingData[, predictedVariable])
      )
    
    modelFunctionReturn <- list(
      name = "latentClass",
      model  = flexmixModel,
      # summ = refitFlexmixModel@components,
      pred = modelPredictionsTraining,
      mape = flexmixTrainingMAPE,
      testingPred = modelPredictions,
      testingMAPE = flexmixTestingMAPE,
      predict = function(model, testDataset){
        predictedVector <- flexmix::predict(model,testDataset,aggregate = TRUE)[[1]][,1]
        return(predictedVector)
        
      },
      
      actualVsPredicted = actualVsPredicted,
      actualVsPredictedComparison = flexmixActualVsPredictedComparison,
      residualVsYhat = residualVsYhat
      
    )
    remove( modelPredictionsTraining,
            flexmixTrainingMAPE,
            modelPredictions,
            flexmixTestingMAPE,
            actualVsPredicted,
            flexmixActualVsPredictedComparison,
            residualVsYhat)
    return(modelFunctionReturn)
  },error = function(e){
    modelFunctionReturn <- list(error = paste0("Latent class regression Failed",as.character(e)))
  })
}

nnModelFunction <- function(trainingData,
                            testingData,
                            predictedVariable,
                            nnLearningRate,
                            nnMomentum,
                            nnHiddenAct,
                            nnEpoch,
                            nnBatchSize,
                            mlpHidden) {
  tryCatch({
    if (nnEpoch %% 1 != 0 ||
        nnEpoch <= 0 ||
        nnEpoch %% 1 < 0 ||
        nnBatchSize %% 1 != 0 ||
        nnBatchSize < 2 ||
        nnBatchSize %% 1 < 0 || !isTRUE(all(c(as.numeric(
          strsplit(mlpHidden, ',')[[1]]
        )) == floor(c(
          as.numeric(strsplit(mlpHidden, ',')[[1]])
        )))) || isTRUE(all(floor(as.numeric(c(
          as.numeric(strsplit(mlpHidden, ',')[[1]])
        ))) <= 0))
    ){ #  
      stop(" The number of epochs,batch size and number of units in hidden layes can only be positive intigers and the batch size must be greater than 1")
    }else{
      set.seed(7)
      x <- trainingData[,!(names(trainingData) %in% predictedVariable)]
      y <- trainingData[,as.character(predictedVariable)]
      
      nnModel <-
        deepnet::nn.train(
          data.matrix(x),
          as.numeric(y),
          hidden = c(as.numeric(strsplit(
            mlpHidden, ','
          )[[1]])),
          activationfun = nnHiddenAct,
          learningrate = nnLearningRate,
          momentum =
            nnMomentum,
          learningrate_scale = 1,
          output = "linear",
          numepochs = nnEpoch,
          batchsize
          = nnBatchSize,
          hidden_dropout = 0,
          visible_dropout = 0
        )
      modelPredictionsTraining <-
        deepnet::nn.predict(nnModel, data.matrix(trainingData[, !(names(trainingData) %in% predictedVariable)]))
      nnTrainingMAPE <-
        mape(y = trainingData[, predictedVariable], yhat = modelPredictionsTraining[, 1])
      modelPredictions <-
        deepnet::nn.predict(nnModel, data.matrix(testingData[, !(names(testingData) %in% predictedVariable)]))
      nnTestingMAPE <-
        mape(y = testingData[, predictedVariable], yhat = modelPredictions[, 1])
      actualVsPredicted <-
        data.frame(predicted = modelPredictionsTraining[, 1] , actual = trainingData[, predictedVariable])
      nnActualVsPredictedComparison <-
        data.frame(
          actual = testingData[, predictedVariable],
          predicted = modelPredictions[, 1],
          model = paste("NN  ", "MAPE = ",
                        round(nnTestingMAPE, 2),
                        "%"),
          id = "NN"
        )
      residualVsYhat <-
        data.frame(
          predicted = modelPredictionsTraining,
          residual = (modelPredictionsTraining[, 1] - trainingData[, predictedVariable])
        )
      modelFunctionReturn <- list(
        name = "nn",
        model  = nnModel,
        pred = modelPredictionsTraining[,1],
        mape = nnTrainingMAPE,
        testingPred = modelPredictions[,1],
        testingMAPE = nnTestingMAPE,
        predict = function(model, testDataset){
          return(deepnet::nn.predict(model,data.matrix(testDataset)))
        },
        
        actualVsPredicted = actualVsPredicted,
        actualVsPredictedComparison = nnActualVsPredictedComparison,
        residualVsYhat = residualVsYhat
        
      )
      remove(modelPredictionsTraining,
             nnTrainingMAPE,
             modelPredictions,
             nnTestingMAPE,
             actualVsPredicted,
             nnActualVsPredictedComparison,
             residualVsYhat)
      return(modelFunctionReturn)
    }
  },error = function(e){
    modelFunctionReturn <- list(error = paste0("Neural Network regression Failed",as.character(e)))
  })
}






# --------------------  Feature importance ---------------



giveRankMARSBasic <-  function(x, y)
{
  earth.mod = earth::earth(x, y)
  ev = earth::evimp(earth.mod, trim=TRUE)
  # remove(earth.mod)
  return(list(ev,earth.mod))
}

MARSRegression <- function(y,newData,dataset)
{
  data_y = dataset[,c(y)]
  data_x = as.matrix(newData[,setdiff(colnames(newData),y)])
  return(giveRankMARSBasic(data_x, data_y))
}


LARSRegression <- function(y, newData, dataset)
{
  data_y = as.numeric(as.factor(dataset[,c(y)]))
  data_x = as.matrix(newData[,setdiff(colnames(newData),y)])
  return(giveRankLARSBasic(data_x, data_y))
}

giveRankLARSBasic <- function(x, y)
{
  print("This is the lars function")
  larsObject = lars::lars(as.matrix(x), y, trace = T, type = "lar")
  index <- which(larsObject$Cp  %in% min(larsObject$Cp))
  tempLarsObj <- larsObject
  tempLarsObj$beta <- tempLarsObj$beta[1:index, , drop = F]
  larsObject <- tempLarsObj
  remove(tempLarsObj)
  beta = abs(larsObject$beta[nrow(larsObject$beta),])
  beta = as.data.frame(sort(beta, decreasing=T), stringsAsFactors = F)
  beta = as.data.frame(cbind(rownames(beta), beta[,1]), stringsAsFactors = F)
  beta[,2] = as.numeric(beta[,2])
  rownames(beta) <- beta[,1]
  colnames(beta) <- c("Importance")
  return(list(beta,larsObject))
}

underscoredTime <- function(time){
  time <- gsub(time,pattern = ":",replacement = "_")
  time <- gsub(time,pattern = "-",replacement = "_")
  return(gsub(time,pattern = " ",replacement = "_"))
}


RandomForestVariableImportance <-function(input.data,dependent.variable,independent.variables,numTrees,mTry,minNodeSize,
                                          splitRule,Importance){
  input.data <- input.data[ , apply(input.data, 2, function(x) !any(is.na(x)))]
  ranger.model <- ranger::ranger(formula = paste0(dependent.variable," ~ ",
                                          paste(independent.variables, collapse = " + ")),
                         data = input.data, importance= Importance, 
                         num.trees = numTrees,mtry=mTry,
                         min.node.size=minNodeSize,splitrule=splitRule,
                         alpha = 0.5, minprop = 0.1)
  
  
  variable.importance <- ranger::importance(ranger.model)
  variable.importance <- as.data.frame(variable.importance)
  variable.importance['variable'] <- row.names(variable.importance)
  variable.importance$variable.importance <-  
    variable.importance$variable.importance/max(variable.importance$variable.importance) * 100
  variable.importance <- variable.importance[order(-variable.importance$variable.importance),]
  row.names(variable.importance) <- variable.importance$variable
  variable.importance$variable <- NULL
  remove(input.data)
  return(list(variable.importance,ranger.model))
}



OLSVarImpFun <- function(predictedVariable,newData, dataset){
  #dataForOLS <- cbind(dataset[,predictedVariable,drop = F], newData)
  dataForOLS <- newData
  colnames(dataForOLS)[1] <- predictedVariable
  stdOLSObject <- stats::lm(formula =stats::as.formula(paste0(predictedVariable,"~.")),data=dataForOLS)
  return(stdOLSObject)
}



PLSVarImpFun <- function(predictedVariable,standardizedData, dataset){
  set.seed(0)
  
  ### Caret package has a dependency on PLS package internally
  library(pls)
  
  dataForPls <- cbind(dataset[,predictedVariable, drop = F], standardizedData)
  colnames(dataForPls)[1] <- predictedVariable
  modelfit <- caret::train(stats::as.formula(paste(predictedVariable,"~.")),data=dataForPls,method="pls")
  res<-caret::varImp(modelfit)    #type:-(1=mean decrease in accuracy, 2=mean decrease in node impurity)
  plsImpTable <- as.matrix(res$importance)
  return(modelfit)
}


xgbVarImpFun <- function(predictedVariable, newData, dataset,xgboostMaxDepthFS,xgboostLeraningRateFS, xgboostNoOfIterationsFS){
  output_vector <- dataset[,predictedVariable]
  numericNewData <- sapply(newData[,-1], function(x) as.numeric(x) )
  bst <- xgboost::xgboost(data = as.matrix(numericNewData), label = output_vector, max.depth = xgboostMaxDepthFS,
                 eta = xgboostLeraningRateFS, nround = xgboostNoOfIterationsFS,objective = "reg:linear", save_period = NULL)
  return(bst)
}


preparePredDataAndRun <- function(predDataSet, blacklist,blacklist_col,modelToPredict,modelSubmit,typeData,trainingData,predictedVariable,catdatainit){
  if (blacklist){
    predDataSet <- predDataSet[,!(colnames(predDataSet) %in% blacklist_col)]  #---------------
  }
  predDataSet <- na.omit(predDataSet)
  categoricalDataUploaded <- predDataSet[as.character(typeData$Column)[which(typeData$Column.Type %in% c("character","factor"))]]
  
  collatedCatData <- rbind(catdatainit[,names(categoricalDataUploaded)],categoricalDataUploaded)
  
 
  dummifiedCatData <- list()
  for(entity in names(collatedCatData)){
      if("Reference.Level" %in% colnames(typeData)){
          dummifiedCatDataList <- DummyVarCreation(collatedCatData[entity],
                                                   referenceLevel = as.character(typeData[which(typeData$Column ==entity),"Reference.Level"]),
                                                   typedata = typeData,predictflag = T)
          
          
          
          
          # names(dummifiedCatDataList[[1]]) <- make.names(names(dummifiedCatDataList[[1]]))
          dummifiedCatData[[entity]] <- dummifiedCatDataList[[1]]
      }else{
          dummifiedCatDataList <- DummyVarCreation(collatedCatData[entity],typedata = typeData,predictflag = T)
          
          # names(dummifiedCatDataList[[1]]) <- make.names(names(dummifiedCatDataList[[1]]))
          dummifiedCatData[[entity]] <- dummifiedCatDataList[[1]]
      }
  }
  # dummifiedCatData <- do.call('cbind',dummifiedCatData)
  dummifiedCatData <- dplyr::bind_cols(dummifiedCatData)
  numericCols <- setdiff(colnames(predDataSet), colnames(collatedCatData))
  if(dim(dummifiedCatData)[1] > 0){
    dummifiedCatData <- dummifiedCatData[(dim(catdatainit)[1]+1):dim(collatedCatData)[1],]
    completeDataDummified <- cbind(dummifiedCatData,predDataSet[,c(numericCols),drop = FALSE])
  }else{
    completeDataDummified <- predDataSet[,c(numericCols)]
  }
  
  colnames(completeDataDummified) <- make.names(colnames(completeDataDummified))
  chosenModel <- modelSubmit[[modelToPredict ]]
  inputData <- completeDataDummified[,(colnames(completeDataDummified) %in% colnames(trainingData[,!(names(trainingData) %in% predictedVariable)]))]
  if(chosenModel$name == 'shrinkage' ||
     chosenModel$name == 'OLS' ||
     chosenModel$name == 'stepwise' ||
     chosenModel$name == 'robust' ||
     chosenModel$name == 'MARS' ||
     chosenModel$name == 'xgboost' ||
     chosenModel$name == 'GAM' ||
     chosenModel$name == 'LARS' ||
     chosenModel$name == 'AdaptiveLASSO' ||
     chosenModel$name == 'latentClass' ||
     chosenModel$name == 'nn' ||
     chosenModel$name == 'QR' ||
     chosenModel$name == 'SVR' ||
     chosenModel$name == 'AveragedModel' ||
     chosenModel$name == 'StackedModel'){
    
    modelPredictionsTraining <- chosenModel$predict(chosenModel$model, inputData)
    
  } else if (chosenModel$name == 'RF' ||
             chosenModel$name == 'PDT'
             ) {
      if(chosenModel$dataMode == 'Dummified Columns'){
          modelPredictionsTraining <- chosenModel$predict(chosenModel$model, inputData)
      }else{
          inputData <- cbind(predDataSet[,c(numericCols),drop = FALSE],categoricalDataUploaded)
          modelPredictionsTraining <- chosenModel$predict(chosenModel$model, inputData)
      }
    
    
    
  }else if(chosenModel$name == 'PLS' ){
    
    modelPredictionsTraining <- chosenModel$predict(chosenModel$model, inputData)
    colnames(modelPredictionsTraining) <- "modelPredictionsTraining"
    
  }else if(chosenModel$name == 'ensembleAverageModel' ){
    
    modelPredictionsTraining <- chosenModel$predict(testDataset=inputData,
                                                    modelIndexDF=data.frame(
                                                      inputModelNames = chosenModel$inputModelNames,
                                                      modelIndex = chosenModel$modelIndex),
                                                    inputModelFunctions=chosenModel$modelPredict,
                                                    predictedVariable=chosenModel$predictedVariable,
                                                    columnsToUse=chosenModel$colNamesToUse,
                                                    untouchedDataset = cbind(predDataSet[,c(numericCols),drop = FALSE],categoricalDataUploaded))
    
  }else if(chosenModel$name == 'ensembleStackingModel' ){
    
    modelPredictionsTraining <- chosenModel$predict(testDataset=inputData,
                                                    modelIndexDF=data.frame(
                                                      inputModelNames = chosenModel$inputModelNames,
                                                      modelIndex = chosenModel$modelIndex),
                                                    inputModelFunctions=chosenModel$modelPredict,
                                                    linearModelForStacking=chosenModel$linearModelForStacking,
                                                    predictedVariable=chosenModel$predictedVariable,
                                                    columnsToUse=chosenModel$colNamesToUse,
                                                    untouchedDataset = cbind(predDataSet[,c(numericCols),drop = FALSE],categoricalDataUploaded))
    
  }
  
  dataToDownload <- cbind(predDataSet,modelPredictionsTraining)
  colnames(dataToDownload)[ncol(dataToDownload)] <- "modelPredictionsTraining"
  return(dataToDownload)
}


buildAvgEnsemble <- function(modelsToAverage,modelSubmit,predictedVariable,trainingData,testingData,mapeData){
  modelsList <- lapply(modelsToAverage, FUN=function(x) modelSubmit[[x]]$model)
  
  predictionsList <- lapply(modelsToAverage, FUN=function(x) modelSubmit[[x]]$testingPred)
  predictionsListTraining <- lapply(modelsToAverage, FUN=function(x) modelSubmit[[x]]$pred)
  avgPredictions <- rowMeans(sapply(lapply(predictionsList, as.vector), cbind))
  avgFitted <- rowMeans(sapply(lapply(predictionsListTraining, as.vector), cbind))
  avgEnsembleMAPE <- mape(y=testingData[,predictedVariable],
                          yhat = avgPredictions)
  avgEnsembleMAPETraining <- mape(y=trainingData[,predictedVariable],
                                  yhat = avgFitted)
  
  mapeWithAvg <- rbind(mapeData, data.frame(Model="AveragedModel", Mape=round(avgEnsembleMAPE,2),  DataType = "Validation"),
                       data.frame(Model="AveragedModel", Mape=round(avgEnsembleMAPETraining,2),  DataType = "Training"))
  validationMapeDataAvg <- mapeWithAvg[mapeWithAvg$DataType == "Validation",]
  levelMape <-validationMapeDataAvg$Model[order(validationMapeDataAvg$Mape)]
  mapeWithAvg$Model = factor(mapeWithAvg$Model, levels = levelMape, ordered=TRUE)
  
  
  forModelSubmit <- list(
    name = "ensembleAverageModel",
    model  = as.vector(lapply(modelsToAverage, FUN=function(x) modelSubmit[[x]]$model)),
    # modelPredict = predictionsList,
    modelPredict = as.vector(lapply(modelsToAverage, FUN=function(x) modelSubmit[[x]])) ,
    inputModelNames = as.vector(modelsToAverage),
    modelIndex = 1:length(modelsToAverage) ,
    
    predictedVariable = predictedVariable,
    
    colNamesToUse = colnames(trainingData[, !colnames(trainingData) %in% predictedVariable]),
    
    pred = avgPredictions,
    mape = avgEnsembleMAPE,
    
    predict = function(testDataset, modelIndexDF, inputModelFunctions,predictedVariable, columnsToUse,untouchedDataset = NULL){
        # saveRDS(inputModelFunctions, file = "inputModelFunctions.rds")
        # modelNamesTmp <- modelIndexDF$inputModelNames
        # if((('PDT' %in% modelNamesTmp) || ('RF' %in% modelNamesTmp)) && ()){
        #     
        # }
        modelnamevec <- sapply(inputModelFunctions,function(obj){return(obj$name)})
        if (('PDT' %in% modelnamevec) || ('RF' %in% modelnamevec)){
            if("Un-Dummified Columns" %in% sapply(inputModelFunctions,function(obj){return(obj$dataMode)})){
                colnamevec <- Filter(f = function(x) !is.null(x) ,x = unique(sapply(inputModelFunctions,function(obj){return(if(!is.null(obj$colsUsed)){obj$colsUsed})})))[[1]]
                testDatasetUndummified <- na.omit(untouchedDataset[,colnamevec,drop = FALSE])
            }
        }
        
      
      testDataset <- testDataset[,!colnames(testDataset) %in% predictedVariable]
      
      testDataset <- na.omit(testDataset)
      
      colnames(testDataset) <- make.names(colnames(testDataset))
      
      testDataset <- testDataset[, colnames(testDataset) %in% columnsToUse]
      
      
      # Predicting using models
      predictionMatrix <- sapply(inputModelFunctions, function(modelList) {
        
        if(modelList$name == 'PDT' || modelList$name == 'RF'){
            return(do.call(modelList$predict,list(modelList$model, testDatasetUndummified)))
        }else{
            do.call(modelList$predict,list(modelList$model, testDataset))
        }
      }
      )
      
      # Final processing for averaging of predictions
      
      ensembleAvgPredictions <- rowMeans(predictionMatrix)
      
      return(ensembleAvgPredictions)
    }
  )
  return(list(mapeWithAvg,forModelSubmit,avgEnsembleMAPE,avgEnsembleMAPETraining))
}

buildStackedEnsemble <- function(modelsToStack,modelSubmit,trainingData,testingData,predictedVariable){
  predictionsList <- lapply(modelsToStack, FUN=function(x) modelSubmit[[x]]$pred)
  predictionsList_testing <- lapply(modelsToStack, FUN=function(x) modelSubmit[[x]]$testingPred)
  modelwiseList <- list()
  for( ind in 1:length(predictionsList)){
    
    modelwiseList[[ind]]  <- unname(predictionsList[[ind]])
  }
  names(modelwiseList) <- modelsToStack
  
  modelwiseList_testing <- list()
  for( ind in 1:length(predictionsList_testing)){
    
    modelwiseList_testing[[ind]]  <- unname(predictionsList_testing[[ind]])
  }
  names(modelwiseList_testing) <- modelsToStack
  
  
  y <- trainingData[,predictedVariable]
  
  y_testing <- testingData[,predictedVariable]
  
  
  x <- cbind(data.frame(modelwiseList), trainingData[,predictedVariable])
  colnames(x) <- c(modelsToStack,as.character(predictedVariable))
  
  x_testing <- cbind(data.frame(modelwiseList_testing), testingData[,predictedVariable])
  colnames(x) <- c(modelsToStack,as.character(predictedVariable))
  
  stackedLmFormula <- stats::as.formula(paste0(predictedVariable," ~ ."))
  stackedLinearModel <- lm(formula = stackedLmFormula,data= x)
  stackedLmPredictions <- predict(stackedLinearModel,x_testing)
  stackedLmFitted <- predict(stackedLinearModel,x)
  stackedMAPE <- mape(y=testingData[,predictedVariable],
                      yhat = stackedLmPredictions)
  stackedMAPETraining <- mape(y=trainingData[,predictedVariable],
                              yhat = stackedLmFitted)
  
  
  formodelSubmit <-  list(
    name = "ensembleStackingModel",
    model  = as.vector(lapply(modelsToStack, FUN=function(x) modelSubmit[[x]]$model)),
    modelPredict = as.vector(lapply(modelsToStack, FUN=function(x) modelSubmit[[x]])) ,
    inputModelNames = as.vector(modelsToStack),
    modelIndex = 1:length(modelsToStack) ,
    
    predictedVariable = predictedVariable,
    
    linearModelForStacking = stackedLinearModel,
    
    colNamesToUse = colnames(trainingData),
    
    pred = stackedLmPredictions,
    mape = stackedMAPE,
    
    predict = function(testDataset, modelIndexDF, inputModelFunctions, linearModelForStacking, predictedVariable, columnsToUse,untouchedDataset = NULL){
        modelnamevec <- sapply(inputModelFunctions,function(obj){return(obj$name)})
        if (('PDT' %in% modelnamevec) || ('RF' %in% modelnamevec)){
            if("Un-Dummified Columns" %in% sapply(inputModelFunctions,function(obj){return(obj$dataMode)})){
                colnamevec <- Filter(f = function(x) !is.null(x) ,x = unique(sapply(inputModelFunctions,function(obj){return(if(!is.null(obj$colsUsed)){obj$colsUsed})})))[[1]]
                testDatasetUndummified <- na.omit(untouchedDataset[,colnamevec,drop = FALSE])
            }
        }
      
      testDataset <- testDataset[,!colnames(testDataset) %in% predictedVariable]
      
      testDataset <- na.omit(testDataset)
      
      
      colnames(testDataset) <- make.names(colnames(testDataset))
      
      testDataset <- testDataset[, colnames(testDataset) %in% columnsToUse]
      
      # Predicting using models
      predictionMatrix <- sapply(inputModelFunctions, function(modelList) {
          if(modelList$name == 'PDT' || modelList$name == 'RF'){
              return(do.call(modelList$predict,list(modelList$model, testDatasetUndummified)))
          }else{
              do.call(modelList$predict,list(modelList$model, testDataset))
          }
      }
      )
      
      # Final processing for stacking
      
      dataPredictStacking <- as.data.frame(predictionMatrix, row.names = NULL)
      
      colnames(dataPredictStacking) <- modelIndexDF$inputModelNames
      
      ensembleStackingPredictions <- predict(linearModelForStacking,dataPredictStacking)
      
      return(ensembleStackingPredictions)
    }
  )
  return(list(stackedMAPE,stackedMAPETraining,formodelSubmit))  
  
}












#Courtesy http://stackoverflow.com/questions/4357031/qqnorm-and-qqline-in-ggplot2/
# ggQQ <- function(LM) # argument: a linear model
# {
#   y <- quantile(LM$resid[!is.na(LM$resid)], c(0.25, 0.75))
#   x <- qnorm(c(0.25, 0.75))
#   slope <- diff(y)/diff(x)
#   int <- y[1L] - slope * x[1L]
#   p <- ggplot2::ggplot(LM, ggplot2::aes(sample=.resid)) +
#     ggplot2::stat_qq(alpha = 0.3) +
#     ggplot2::geom_abline(slope = slope, intercept = int, color="blue",alpha=0.7,linetype='dashed')+
#     ggplot2::ggtitle("Residual distribution vs Normal distribution ")
#   
#   return(p)
# }



# inDataType_func <- function(conList, dbName){
#   # ref <- dataRefresh$refresh
#   #conList <- inDataReactive$inData
#   
#   if(is.null(conList$con)){ # CSV --------
#     dat <- conList$table
#   }
#   else { # DB  ---------
#     fn <- function(){tryCatch(dbFetchTop(conList, dbName),warning=function(w){message(w[1]);dbFetchTop(conList, dbName)},error=function(e){message(e[1])})}
#     dat <- fn()
#     #inDataHead <<- dat
#   }
#   
#   if(is.null(dat)) return(NULL)
#   dat <- collect(head(dat,n=10))
#   
#   dtypes <-unlist(lapply(lapply(dat,class),function(x){return(x[1])}))
#   data.frame(col=colnames(dat),dataType=dtypes,stringsAsFactors = F)
#}


clearResults <- function(con){
  if(class(con)=='SQLiteConnection') return()
  if(dbResultLen(con)){
    dbClearResult(dbListResults(con)[[1]])
  }
}

# dbResultLen <- function(con){
#   return(length(dbListResults(con)))
# } 


### The paths should be relative to the source file, changed it in the version 17.12.03 ###
## Report download
downloadReport <- function(working_dir, reactData, input, fileName){
  rmarkdown::render('Source/RegressionReport.rmd',
                    params = list(workingDir = working_dir,
                                  reactData = reactData,
                                  input = input),
                    switch(input$format,
                           PDF = pdf_document(),
                           PrettyHTML = prettydoc::html_pretty(css = paste0(working_dir ,
                                                                            "../Styles/pretty_styles.css")),
                           HTML = rmarkdown::html_document(css = paste0(working_dir,"../Styles/styles.css") ,toc= T,toc_float= T),
                           
                           MSWord = word_document(toc = T)
                    ),output_dir = paste0(working_dir,"Downloads/") , output_file = paste(fileName,
                                                                                           switch( input$format, PDF = '.pdf', HTML = '.html',
                                                                                                   PrettyHTML = '_pretty.html', MSWord = ".doc"
                                                                                           ),sep='')
  )
}


# custom mape function
calcF1 <- function(data, lev = NULL, model = NULL) {
  f1 <- MLmetrics::MAPE(y_true = data$obs, y_pred = data$pred)
  c(F1 = f1)
}




runlmCrossValidation <- function(cvControl, x, y, color, interceptflag){
  models <- caret::train(method = 'lm', trControl = cvControl, x = x, y = y, metric= 'F1', tuneGrid  = expand.grid(intercept = interceptflag))
  # return(models$resample)


return(ggplot2::ggplot(models$resample, ggplot2::aes(x = Resample,y = F1)) + 
          ggplot2::geom_bar(color=color, fill = color,stat = "identity",position = "dodge") + 
           ggplot2::ylab("MAPE") + ggplot2::xlab("Fold") + 
          ggplot2::labs(title= "MAPE Across cross validation sets") + ggplot2::theme(plot.title = ggplot2::element_text(hjust = 0.5)))

}



runstepwiseCrossValidation <- function(cvControl, x, y, color, direction, interceptflag){
  predictedVariable <- names(y)[[1]]
  if(interceptflag){
    stepwiseFormula <- stats::as.formula(paste0(predictedVariable," ~ ."))
      
  }else{
    stepwiseFormula <- stats::as.formula(paste0(predictedVariable," ~ . -1"))
  }
  dataset = cbind(x,y) 
  models <- caret::train(stepwiseFormula,method = 'lmStepAIC', trControl = cvControl, data = dataset, metric= 'F1',direction = direction)

  return(ggplot2::ggplot(models$resample, ggplot2::aes(x = Resample,y = F1)) + 
          ggplot2::geom_bar(color=color, fill = color,stat = "identity",position = "dodge") + 
           ggplot2::ylab("MAPE") + ggplot2::xlab("Fold") + 
          ggplot2::labs(title= "MAPE Across cross validation sets") + ggplot2::theme(plot.title = ggplot2::element_text(hjust = 0.5)))

}



runRobustCrossValidation <- function(cvControl,x,y,color,interceptflag){
  predictedVariable <- names(y)[[1]]
  if (interceptflag){
    robustFormula <- stats::as.formula(paste0(predictedVariable," ~ ."))
    
  }else{
    robustFormula <- stats::as.formula(paste0(predictedVariable," ~ . -1"))
  }
  dataset = cbind(x,y) 
  
  models <- caret::train(robustFormula,method = 'rlm', trControl = cvControl, data = dataset, metric= 'F1')  

  return(ggplot2::ggplot(models$resample, ggplot2::aes(x = Resample,y = F1)) + 
          ggplot2::geom_bar(color=color, fill = color,stat = "identity",position = "dodge") + 
           ggplot2::ylab("MAPE") + ggplot2::xlab("Fold") + 
          ggplot2::labs(title= "MAPE Across cross validation sets") + ggplot2::theme(plot.title = ggplot2::element_text(hjust = 0.5)))
}





runGAMCrossValidation <- function(trainingData,
                                 predictedVariable,
                                 smoothListCol,
                                 gamWithIntercept,
                                 color1,
                                 cvK){
    gamTrainingData <- as.data.frame(trainingData[, -which(colnames(trainingData) %in% predictedVariable)])
    colnames(gamTrainingData) <- colnames(trainingData)[-which(colnames(trainingData) %in% predictedVariable)]
    
    # Columns to be applied a smoothening parameter must be seperated in formula
    
    colToRemove <- as.character(smoothListCol)
    if(length(colToRemove) != 0){
        gamTrainingData <- gamTrainingData[, -which(colnames(gamTrainingData) %in% colToRemove),drop = FALSE]
        
        col <- paste("s(",smoothListCol,")+",sep = '',collapse = '')
        colToSmooth <- substr(col,1,nchar(col)-1)
    }else{
        colToSmooth <- c()}
    # Columns on which smoothening parameter must not be applied  
    
    nonSmoothPredictor<- paste(colnames(gamTrainingData),collapse = "+")
    
    if(length(colnames(gamTrainingData))==0){
        dependentVariable <-colToSmooth
    }else{
        dependentVariable <- paste(c(colToSmooth,nonSmoothPredictor), collapse = "+" )
    }
    
    # Example of hyperparameter changing
    
    if (gamWithIntercept){
        gamFormula <- stats::as.formula(paste0(predictedVariable,"~",dependentVariable))
    }else{
        gamFormula <- stats::as.formula(paste0(predictedVariable, "~", "-1 + ", dependentVariable))
    }
    
    resample <- NULL
    folds <- caret::createFolds(y = trainingData[,predictedVariable],
                                k = cvK,
                                list = TRUE)
    fill <- rep(NA, length(folds))
    resample <- data.frame(Resample = names(folds), F1 = fill)
    for(i in 1:length(folds)) {
        
        # build model
        model <- tryCatch(mgcv::gam(formula = gamFormula, data= trainingData),
        error = function(e) NA
        )
    
    if(class(model)[1] == 'gam') {
        validation <- trainingData[folds[[i]],,drop = FALSE]
        preds <- predict(model, validation)
        
        # adding metrics to their global variables
        resample[i, 'F1'] <- mape(y=validation[,predictedVariable],
                                  yhat = preds)
        
    } else {
        warning('Model could not be built, so returning NAs')
    }
    remove(model,validation, preds)

    }
    return(ggplot2::ggplot(resample, ggplot2::aes(x = Resample,y = F1)) + 
               ggplot2::geom_bar(color=color1, fill = color1,stat = "identity",position = "dodge") + 
               ggplot2::ylab("MAPE") + ggplot2::xlab("Fold") + 
               ggplot2::labs(title= "MAPE Across cross validation sets") + ggplot2::theme(plot.title = ggplot2::element_text(hjust = 0.5)))
    
}

runQuantileCrossValidation <- function(cvControl,x,y,color,interceptflag){
  
  predictedVariable <- names(y)[[1]]
  
  if (interceptflag){
    
    QRFormula <- paste0(predictedVariable," ~ .")
  }else{
    QRFormula <- paste0(predictedVariable," ~ . -1")
  }
  dataset = cbind(x,y) 
  
  models <- caret::train(stats::as.formula(QRFormula), method = 'rqlasso', trControl = cvControl,data = dataset,tuneGrid = data.frame(lambda = 0), metric = 'F1')
  
  return(ggplot2::ggplot(models$resample, ggplot2::aes(x = Resample,y = F1)) + 
          ggplot2::geom_bar(color=color, fill = color,stat = "identity",position = "dodge") + 
           ggplot2::ylab("MAPE") + ggplot2::xlab("Fold") + 
          ggplot2::labs(title= "MAPE Across cross validation sets") + ggplot2::theme(plot.title = ggplot2::element_text(hjust = 0.5)))
}

runShrinkCrossValidation <- function(x,y,color,cvControl){
    shrinkagelm <- list(type = "Regression",
                        library = "shrink",
                        loop = NULL)
    
    prm <- data.frame(parameter = "dummy",
                      class = "numeric",
                      labels = "dummy")
    shrinkagelm$parameters <- prm
    
    
    shrinkGrid <- function(x, y, len = NULL, search = "grid"){
        return(expand.grid(dummy = seq(1:2)))
    }
    
    shrinkagelm$grid <- shrinkGrid
    
    shrinkFit <- function(x, y, wts = NULL, param = NULL, lev = NULL, last = TRUE, weights = NULL, classProbs = FALSE,dummy = NULL){
        predictedVariable <- "yVar"#names(y)[[1]]
        y <- data.frame(yVar = y)
        dataset <- cbind(x,y)
        shrinkageFormula <- stats::as.formula(paste0(predictedVariable," ~ ."))
        lmfit <- lm(formula = shrinkageFormula, data = dataset, x = TRUE, y = TRUE)
        shrinkageModel <- shrink::shrink(lmfit, type = 'global', method = 'dfbeta')
        return(shrinkageModel)
    }
    shrinkagelm$fit <- shrinkFit
    
    
    shrinkPred <- function(modelFit, newdata, preProc = NULL, submodels = NULL,dummy = NULL){
        return(((modelFit$ShrunkenRegCoef[-(1:1)]%*%t( newdata) ) + modelFit$ShrunkenRegCoef[1])[1,])
    }
    
    shrinkagelm$predict <- shrinkPred
    
    
    
    
    
    shrinkagelm$prob <- function(modelFit, newdata, preProc = NULL, submodels = NULL){
        return((modelFit$ShrunkenRegCoef[-(1:1)]%*%t( newData) ) + modelFit$ShrunkenRegCoef[1])
    }
    
    
    shrinkagelm$sort <- function(x){return(x)}
    shrinkagelm$levels <- function(x){return(x)}
    # Y <- y[,drop = TRUE]
    models <- caret::train( method = shrinkagelm,x = x, y = y, trControl = cvControl, metric = 'F1')
    return(ggplot2::ggplot(models$resample, ggplot2::aes(x = Resample,y = F1)) + 
               ggplot2::geom_bar(color=color, fill = color,stat = "identity",position = "dodge") + 
               ggplot2::ylab("MAPE") + ggplot2::xlab("Fold") + 
               ggplot2::labs(title= "MAPE Across cross validation sets") + ggplot2::theme(plot.title = ggplot2::element_text(hjust = 0.5)))
    
}

runGLMCrossValidation <- function(x,y,color,cvControl){
    predictedVariable <- names(y)[[1]]
    dataset <- cbind(x,y)
    models <- caret::train(stats::as.formula(paste0(predictedVariable, " ~.")),
                           method = 'glmnet',
                           metric = 'F1',
                           data = dataset,
                           trControl = cvControl,
                           tuneGrid = data.frame(alpha = 1, lambda = 0), family = 'gaussian')
    
    return(ggplot2::ggplot(models$resample, ggplot2::aes(x = Resample,y = F1)) + 
               ggplot2::geom_bar(color=color, fill = color,stat = "identity",position = "dodge") + 
               ggplot2::ylab("MAPE") + ggplot2::xlab("Fold") + 
               ggplot2::labs(title= "MAPE Across cross validation sets") + ggplot2::theme(plot.title = ggplot2::element_text(hjust = 0.5)))
}

runPLSCrossValidation <- function(x,y,color,cvControl,ncomp){
    predictedVariable <- names(y)[[1]]
    dataset <- cbind(x,y)
    models <- caret::train(stats::as.formula(paste0(predictedVariable, "~ .")), data = dataset, metric = 'F1', method = 'pls',trControl = cvControl, tuneGrid = data.frame(ncomp = ncomp))
    return(ggplot2::ggplot(models$resample, ggplot2::aes(x = Resample,y = F1)) + 
               ggplot2::geom_bar(color=color, fill = color,stat = "identity",position = "dodge") + 
               ggplot2::ylab("MAPE") + ggplot2::xlab("Fold") + 
               ggplot2::labs(title= "MAPE Across cross validation sets") + ggplot2::theme(plot.title = ggplot2::element_text(hjust = 0.5)))

}


runMARSCrossValidation <- function(x,y,color,cvControl){
    predictedVariable <- names(y)[[1]]
    dataset <- cbind(x,y)
    
    models <- caret::train(stats::as.formula(paste0(predictedVariable," ~.")),
                           data = dataset,
                           method = 'earth',
                           trControl = cvControl,
                           metric = 'F1')
    return(ggplot2::ggplot(models$resample, ggplot2::aes(x = Resample,y = F1)) + 
               ggplot2::geom_bar(color=color, fill = color,stat = "identity",position = "dodge") + 
               ggplot2::ylab("MAPE") + ggplot2::xlab("Fold") + 
               ggplot2::labs(title= "MAPE Across cross validation sets") + ggplot2::theme(plot.title = ggplot2::element_text(hjust = 0.5)))
}

runPDTCrossValidation <- function(x,y,cvControl,color,PDTpValue, PDTminsplit, PDTminbucket, k){
    predictedVariable <- names(y)[[1]]
    dataset <- cbind(x,y)
    train_control<- caret::trainControl(method="cv", number=k, savePredictions = TRUE)
    models <- caret::train(stats::as.formula(paste0(predictedVariable," ~.")),
                           data = dataset,
                           method = 'ctree',
                           trControl = train_control,
                           controls = party::ctree_control(minsplit = PDTminsplit, minbucket = PDTminbucket),
                           tuneGrid = data.frame(mincriterion = PDTpValue))
    return(ggplot2::ggplot(models$resample, ggplot2::aes(x = Resample,y = RMSE)) + 
               ggplot2::geom_bar(color=color, fill = color,stat = "identity",position = "dodge") + 
               ggplot2::ylab("MAPE") + ggplot2::xlab("Fold") + 
               ggplot2::labs(title= "MAPE Across cross validation sets") + ggplot2::theme(plot.title = ggplot2::element_text(hjust = 0.5)))
}


runRFCrossValidtion <- function(x,y,RFNoOfTrees,RFmtry,RFMinNodeSize,cvControl,color){
    predictedVariable <- names(y)[[1]]
    dataset <- cbind(x,y)
   
    models <- caret::train(stats::as.formula(paste0(predictedVariable," ~.")),
                           data = dataset,
                           trControl = cvControl,
                           method = 'ranger',
                           num.trees = RFNoOfTrees,
                           # importance = 'impurity',
                           # replace = TRUE,
                           alpha = 0.5, 
                           minprop = 0.1,
                           tuneGrid = data.frame(mtry = RFmtry, splitrule= "variance",min.node.size = RFMinNodeSize),metric = 'F1')
    return(ggplot2::ggplot(models$resample, ggplot2::aes(x = Resample,y = F1)) + 
               ggplot2::geom_bar(color=color, fill = color,stat = "identity",position = "dodge") + 
               ggplot2::ylab("MAPE") + ggplot2::xlab("Fold") + 
               ggplot2::labs(title= "MAPE Across cross validation sets") + ggplot2::theme(plot.title = ggplot2::element_text(hjust = 0.5)))
}


runxgBoostCrossValidation <- function(x,y,cvControl,xgboostNoOfIterations,xgboostLeraningRate,xgboostMaxDepth,color){
    predictedVariable <- names(y)[[1]]
    dataset <- cbind(x,y)
    models <- caret::train(stats::as.formula(paste0(predictedVariable," ~.")),
                           data = dataset,
                           method = 'xgbLinear',
                           trControl = cvControl,
                           tuneGrid = data.frame(eta = xgboostLeraningRate,
                                                 nrounds = xgboostNoOfIterations,
                                                 lambda = 0, alpha = 0),
                           max.depth = xgboostMaxDepth,
                           booster = 'gbtree',metric = 'F1')
    
    return(ggplot2::ggplot(models$resample, ggplot2::aes(x = Resample,y = F1)) + 
               ggplot2::geom_bar(color=color, fill = color,stat = "identity",position = "dodge") + 
               ggplot2::ylab("MAPE") + ggplot2::xlab("Fold") + 
               ggplot2::labs(title= "MAPE Across cross validation sets") + ggplot2::theme(plot.title = ggplot2::element_text(hjust = 0.5)))
    
}

runSVRCrossValidation <- function(cvk,x,y,color){
    predictedVariable <- names(y)[[1]]
    trainingData <- cbind(x,y)
    resample <- NULL
    folds <- caret::createFolds(y = trainingData[,predictedVariable],
                                k = cvk,
                                list = TRUE)
    fill <- rep(NA, length(folds))
    resample <- data.frame(Resample = names(folds), F1 = fill)
    SVRFormula <- stats::as.formula(paste0(predictedVariable," ~ ."))
    for(i in 1:length(folds)) {
        
        # build model
        model <- tryCatch(e1071::svm(SVRFormula,data= trainingData),
                          error = function(e) NA
        )
        
        # if(class(model)[1] == 'gam') {
            validation <- trainingData[folds[[i]],,drop = FALSE]
            preds <- predict(model, validation)
            
            # adding metrics to their global variables
            resample[i, 'F1'] <- mape(y=validation[,predictedVariable],
                                      yhat = preds)
            
        # } else {
            # warning('Model could not be built, so returning NAs')
        # }
        remove(model,validation, preds)
        
    }
    return(ggplot2::ggplot(resample, ggplot2::aes(x = Resample,y = F1)) + 
               ggplot2::geom_bar(color=color, fill = color,stat = "identity",position = "dodge") + 
               ggplot2::ylab("MAPE") + ggplot2::xlab("Fold") + 
               ggplot2::labs(title= "MAPE Across cross validation sets") + ggplot2::theme(plot.title = ggplot2::element_text(hjust = 0.5)))
}






runFlexmixCrossValidation <- function(x,y,color,cvControl,cvk){
    ###### Flexmix - caret interface infra code begins ------------------->
    
    flexmixTrain <- list(type = "Regression", library = "flexmix", loop =NULL)
    
    
    prm <- data.frame(parameter = "nrep", class = "numeric", label = "nrep")
    
    flexmixTrain$parameters <- prm
    
    flexmixGrid <- function(x,y,len = NULL, search = "grid"){
        data.frame(nrep = 3)
    }
    
    
    flexmixTrain$grid <- flexmixGrid
    
    
    flexmixFit <- function(x, y, wts, param, lev, last, classProbs,...){
        dat <- if(is.data.frame(x))
            x
        else as.data.frame(x)
        dat$.outcome <- y
        # safekeeping for unused args
        p <- param; wt <- wts; leve <- lev; cp <- classProbs;
        stepFlexmixModel <- flexmix::stepFlexmix(.outcome ~., 
                                        nrep = param$nrep, 
                                        k = 1:5, 
                                        data = dat,
                                        drop=FALSE, 
                                        unique=FALSE,
                                        control = list(iter = 1000,tol = 1e-08, verbose = 0))
        flexmixModel <- flexmix::getModel(stepFlexmixModel, which = "BIC")
        refitFlexmixModel <- flexmix::refit(flexmixModel)
        flexmixModel
    }
    
    flexmixTrain$fit <- flexmixFit
    
    
    flexmixPred <- function(modelFit, newdata, submodels = NULL){
        flexmix::predict(modelFit,data.frame(newdata), aggregate = TRUE)[[1]][,1]
    }
    
    
    
    flexmixTrain$predict <- flexmixPred
    flexmixTrain$prob <- function(x){NULL}
    flexmixTrain$sort <- function(x){x}
    flexmixTrain$predictors <- NULL#function(x,...){predictors(x$terms)}
    flexmixTrain$levels <- function(x) lev(x)
    
    
    ###### Flexmix - caret interface infra code ends <-------------------
    predictedVariable <- names(y)[[1]]
    dataset <- cbind(x,y)
    models <- caret::train(stats::as.formula(paste0(predictedVariable, " ~.")),
                           data = dataset,
                           method = flexmixTrain,
                           trControl = cvControl,
                           tuneGrid = data.frame(nrep = cvk),metric = 'F1')
    return(ggplot2::ggplot(models$resample, ggplot2::aes(x = Resample,y = F1)) + 
               ggplot2::geom_bar(color=color, fill = color,stat = "identity",position = "dodge") + 
               ggplot2::ylab("MAPE") + ggplot2::xlab("Fold") + 
               ggplot2::labs(title= "MAPE Across cross validation sets") + ggplot2::theme(plot.title = ggplot2::element_text(hjust = 0.5)))
}



#################################################################################################



DummyVarCreation <- function(columnToConvert, outPath = getwd(), fileName = paste("DummyVariableLog_", deparse(substitute(columnToConvert)), sep = ""), 
                             referenceLevel = NA, cutoffValue = 20,typedata = NA,predictflag = F) {
    numVar <- c()
    strCat <- c()
    levelDropVec <- c()
    rmcol <- c()
    colDummyMap <- list()
    typeData <- typedata
    if (length(columnToConvert) > 0){
        
        #Creating dummy columns to remove
        dummyColsToRemove <- c()
        
        if(is.na(referenceLevel) || is.null(referenceLevel) || referenceLevel == ""){
            freqDf <- data.frame(table(columnToConvert))
            minFreqVal <- freqDf[which.min(freqDf[, 2]), 1 ]
            minFreqVal <- as.character(minFreqVal)
            
            referenceLevel <- minFreqVal
            if(predictflag == T){
                referenceLevel <- typeData[which(typeData$Column == names(columnToConvert)[1]),"Forced.Reference"]
            }
            
            if(predictflag == F){
                typeData[which(typeData$Column == names(columnToConvert)[1]),"Forced.Reference"] <- referenceLevel
            }
        }
        
        columnName <- names(columnToConvert[1])
        
        columnToConvert[[1]] <- as.character(columnToConvert[[1]])
        
        names(columnToConvert) <- columnName
        
        dummyColsToRemove <- c(dummyColsToRemove, referenceLevel)
        
        levelDropVec <- c(levelDropVec, paste(colnames(columnToConvert), sep = "_", referenceLevel))
        
        #creation of dummy variables 
        
        if(length(unique(columnToConvert[[1]]))>2){
            dummys <- dummies::dummy.data.frame(columnToConvert, names = colnames(columnToConvert), sep = "_")
            #Removal of columns
            
            dummys <- dummys[, !colnames(dummys) %in% levelDropVec]
            
        }else{
            # If its a binary column
            dummys <- as.data.frame(as.numeric(columnToConvert != referenceLevel))
            colnames(dummys) <- paste(colnames(columnToConvert),
                                      unique(columnToConvert)[unique(columnToConvert) != referenceLevel],sep='_')
        }
        
    }
    return(list('dummies' = dummys, 'metadata'  = typeData))
}

























#################################################################################################



# runCustomCrossValidation <- function(modelname, cvk,x,y,color,hyperParameerList = NULL){
#     predictedVariable <- names(y)[[1]]
#     dataset <- cbind(x,y)
#     for(split in 1:cvk){   # Looping over every combinaton of train and test set
#         splitData <- obtsinDataSplit(dataset, k = cvk,kseq =  split)
#         trainingSet <- splitData$trainSet
#         testSet <- splitData$testSet
#         
#         mapeList <- list()
#         if(modelname == "shrinkage"){
#           shrinkageFormula <- stats::as.formula(paste0(predictedVariable," ~ ."))
#           lmfit <- stats::lm(formula = shrinkageFormula,data= trainingSet, x = T, y = T)
#           shrinkageModel <- shrink::shrink(lmfit, type = "global", method = "dfbeta")
#           testInput <- testSet[,!(names(testSet)) %in% c(predictedVariable)]
#           modelPredictions <- (shrinkageModel$ShrunkenRegCoef[-(1:1)]%*%t(testInput) ) + shrinkageModel$ShrunkenRegCoef[1]
#           shrinkageTestingMAPE <- mape(y=testSet[,predictedVariable],yhat = t(modelPredictions)) 
#           mapeList[[paste0('Fold_',split)]] <- shrinkageTestingMAPE
#         }else if(modelname == 'PLS'){
# 
#         }else if(modelname == 'GAM'){
# 
#         }else if(modelname == 'flexmix'){
# 
#         }else if(modelname == 'nn'){
# 
#         }
#         
# 
# 
#         mapeMat <- t(data.frame(mapeList))
#         mapedf <- data.frame(mapeMat)
#         names(mapedf) <- "F1"
#         mapedf$Resample <- rownames(mapedf)
#         return(mapedf)
#     }
# }

obtainSplitIndices <- function(dataset, k){
    chunkSize <- floor(nrow(dataset)/k)
    # testSeq <- (chunkSize*kseq):(chunkSize*kseq+(chunkSize-1))
    testSeq <-  lapply(seq(1,nrow(dataset),chunkSize), function(x) (1:nrow(dataset))[x:(x+(chunkSize-1))])
    listOFTests <- as.list(data.table::transpose(na.omit(data.table::transpose(data.frame(testSeq)))))
    names(listOFTests) <- 1:length(listOFTests)
    mainseq <- 1:nrow(dataset)
    trainSeq <- list()
    for(i in 1:k){
        trainSeq[[i]] <- mainseq[! mainseq %in% listOFTests[[as.character(i)]]]    
    }
    return(list(trainingSet = trainSeq, testSet = listOFTests))
}

obtsinDataSplit <- function(dataset, k, kseq){
    if(kseq > k){
        stop("you can't ask for a split section that is byond the number of splits")
    }
    indexList <- obtainSplitIndices(dataset = dataset, k = k)
    return(list(trainSet = dataset[indexList$trainingSet[[kseq]],], testSet = dataset[indexList$testSet[[as.character(kseq)]],]))
}

avgColor <- function(primaryColor, secondaryColor){
  pc <- grDevices::col2rgb(primaryColor)[,1]
  sc <- grDevices::col2rgb(secondaryColor)[,1]
  meanCol <- round(sqrt((sc ^ 2 + pc ^ 2) / 2))
  return(rgb(255-meanCol[1], 255-meanCol[2], 255-meanCol[3], maxColorValue = 255))
}

# function to align the contents in a data table

columnalign <- function(x) {
  columnclass <- lapply(x, class)
  return(unname(unlist(which(columnclass != "factor")-1)))
}


generateDistributionPlot <- function(data, indexes, predVariable, color, secColor, mode){
  library(dplyr)
  if(mode == "train")
    {data <- data[indexes, predVariable, drop = F]}
  else{
    data <- data[-indexes, predVariable, drop = F]}
  p1<- ggplot2::ggplot(data,
                         ggplot2::aes(x = data[,predVariable])) +
      ggplot2::geom_histogram(
        ggplot2::aes(y = ..count..),
        fill = color,
        size = 0.2,
        alpha=0.7
      ) +
      ggplot2::xlab(predVariable) +
      ggplot2::ylab("Count") +ggplot2::labs(predVariable) +ggplot2::theme_bw() + 
      ggplot2::theme(panel.border=ggplot2::element_rect(size=0.1),legend.position = c(0.8, 0.8),panel.grid.major.x=ggplot2::element_blank()) 
  
  p2<-ggplot2::ggplot(data,
                      ggplot2::aes(x = data[,predVariable])) +
    ggplot2::stat_function(ggplot2::aes(color = "Normal"), fun = dnorm,args = list(mean = mean(data[, predVariable]),sd = sd(data[, predVariable]))) +
    ggplot2::stat_density(ggplot2::aes(color = "Density"), geom = "line", linetype = "dashed")  +
    ggplot2::scale_colour_manual("", values = c(secColor, "#EE7600")) +
    ggplot2::scale_linetype_manual("", 
                                   values = c("Normal" = 2, "Density" = 1))  +
    ggplot2::guides(
      fill = ggplot2::guide_legend(keywidth = 1, keyheight = 1),
      linetype = ggplot2::guide_legend(keywidth = 3, keyheight = 1),
      colour = ggplot2::guide_legend(keywidth = 3, keyheight = 1)
    ) + 
    ggplot2::ylab("Density") +
    ggplot2::xlab("Density") +
    ggplot2::theme(
      panel.background = ggplot2::element_blank(),
      panel.grid.minor = ggplot2::element_blank(),
      panel.grid.major = ggplot2::element_blank(),
      axis.text.y = ggplot2::element_text(colour="black", size=8),
      axis.text.x = ggplot2::element_text(size = 14),
      axis.ticks = ggplot2::element_line(colour = 'gray50'),
      axis.ticks.x = ggplot2::element_line(colour = "black"))
  
  g1 <- ggplot2::ggplotGrob(p1)
  g2 <- ggplot2::ggplotGrob(p2)
  
  pp <- c(subset(g1$layout, name == "panel", se = t:r))
  
  # superimpose p2 (the panel) on p1
  g <- gtable::gtable_add_grob(g1, g2$grobs[[which(g2$layout$name == "panel")]], pp$t, 
                               pp$l, pp$b, pp$l)
  
  # extract the y-axis of p2
  ia <- which(g2$layout$name == "axis-l")
  ga <- g2$grobs[[ia]]
  ax <- ga$children[[2]]
  
  # flip it horizontally
  ax$widths <- rev(ax$widths)
  ax$grobs <- rev(ax$grobs)
  
  # add the flipped y-axis to the right
  g <- gtable::gtable_add_cols(g, g2$widths[g2$layout[ia, ]$l], length(g$widths) - 1)
  g <- gtable::gtable_add_grob(g, ax, pp$t, length(g$widths) - 1, pp$b)
  distHistogram <- g
  return(distHistogram)
}

