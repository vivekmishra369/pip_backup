oldVersionPopup <- function(input, output)
{
  tryCatch({
    user = "foundation.bricks"
    password = "Musigma@2018"
    brickDatabase <- c()
    getContent <- function(id, objects) {
      url <-
        paste0(
          'https://eoc.mu-sigma.com/alfresco/api/-default-/public/alfresco/versions/1/nodes/',
          id,
          objects
        )
      r <-
        httr::GET(url,
                  httr::authenticate(user = user, password = password),
                  httr::timeout(5))
      url_content <- rjson::fromJSON(rawToChar(r$content))
      return(url_content)
    }
    
    getBricksRecursively <- function(brickFolder) {
      for (i in 1:length(brickFolder)) {
        brickDatabase <<-
          c(brickDatabase, brickFolder[[i]]$entry$name)
      }
    }
    logicalResults  <-  lapply(brickFolders, function(x) {
      getBricksRecursively(getContent(x, '/children')$list$entries)
    })
    
    
    
    filename <-
      rjson::fromJSON(file = 'Source/Description.json')['filename']
    latestbrick <-  brickDatabase[grep(filename, brickDatabase)][1]
    w <- strsplit(latestbrick[[1]], "_")[[1]]
    latest_version <- strsplit(w[length(w)], ".zip")
    version <-
      rjson::fromJSON(file = 'Source/Description.json')['version']
    
    if (latest_version > paste0("v", version))
      # if(1)
    {
      output$popStart_2 <-
        shiny::renderUI({
          shiny::tags$div(class = "whiteBox_2", "")
        })
      
      output$popStart <-
        shiny::renderUI({
          shiny::tagList(
            shiny::tags$div(
              class = "whiteBox",
              shiny::tags$p(
                id = "headPopup",
                "Older Version Detected",
                style = "color:red;"
              ),
              shiny::tags$hr(),
              shiny::tags$p(
                id = "bodyPopup",
                "Hey! Looks like you are using an older version of this brick. We recommend you to download the latest version",
                style = "color:red;font-size=18px"
              ),
              shiny::tags$hr(),
              shiny::actionButton("closePopup", "Close")
            )
          )
        })
      
      
      
      shiny::observeEvent(input$closePopup,
                          {
                            output$popStart <- shiny::renderUI({
                            })
                            output$popStart_2 <- shiny::renderUI({
                            })
                          })
      
    }
  }, error = function(e) {
    print(e)
  })
}
