from __future__ import absolute_import, unicode_literals
from .premailer import Premailer, transform  # noqa

__version__ = "3.6.1"
